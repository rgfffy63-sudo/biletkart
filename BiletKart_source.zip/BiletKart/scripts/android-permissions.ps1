# Добавляет в Android-приложение разрешение на микрофон (голосовые ответы)
$m = Join-Path $PSScriptRoot '..\android\app\src\main\AndroidManifest.xml'
$x = [IO.File]::ReadAllText($m)
if ($x -notmatch 'RECORD_AUDIO') {
  $add = "<uses-permission android:name=`"android.permission.RECORD_AUDIO`" />`r`n    <queries><intent><action android:name=`"android.speech.RecognitionService`" /></intent></queries>`r`n`r`n    <application"
  $i = $x.IndexOf('<application')
  $x = $x.Substring(0, $i) + $add + $x.Substring($i + '<application'.Length)
  [IO.File]::WriteAllText($m, $x)
  Write-Host 'Разрешение на микрофон добавлено'
}
