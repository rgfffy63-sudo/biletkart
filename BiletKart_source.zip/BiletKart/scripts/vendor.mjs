// Копирует библиотеки из node_modules в web/vendor, чтобы приложение работало без интернета.
// Запуск: npm install, затем npm run vendor
import { cpSync, mkdirSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const nm = join(root, "node_modules"), out = join(root, "web", "vendor");
mkdirSync(out, { recursive: true });
const files = [
  ["marked/lib/marked.umd.js", "marked.umd.js"],
  ["dompurify/dist/purify.min.js", "purify.min.js"],
  ["@highlightjs/cdn-assets/highlight.min.js", "highlight.min.js"],
  ["mermaid/dist/mermaid.min.js", "mermaid.min.js"],
  ["mathjs/lib/browser/math.js", "math.min.js"],
  ["pdfjs-dist/build/pdf.min.js", "pdf.min.js"],
  ["pdfjs-dist/build/pdf.worker.min.js", "pdf.worker.min.js"],
  ["mammoth/mammoth.browser.min.js", "mammoth.browser.min.js"],
];
let ok = 0;
for (const [from, to] of files) {
  const src = join(nm, from);
  if (!existsSync(src)) { console.warn("  нет файла:", from, "— сначала выполни npm install"); continue; }
  cpSync(src, join(out, to)); ok++;
}
const mj = join(nm, "mathjax", "es5");
if (existsSync(mj)) { cpSync(mj, join(out, "mathjax"), { recursive: true }); ok++; } else console.warn("  нет MathJax — сначала npm install");
console.log(`Готово: скопировано ${ok} из ${files.length + 1} библиотек в web/vendor`);
