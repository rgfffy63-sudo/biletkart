@echo off
chcp 65001 >nul
title BiletKart: Android build
cd /d "%~dp0"
if exist "C:\Program Files\Android\Android Studio\jbr\bin\java.exe" set "JAVA_HOME=C:\Program Files\Android\Android Studio\jbr"
if not defined ANDROID_HOME set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if not exist "%ANDROID_HOME%" (
  echo Не найден Android SDK в %ANDROID_HOME%.
  echo Установи Android Studio, запусти её один раз и дождись загрузки компонентов.
  pause & exit /b 1
)
if not defined JAVA_HOME (
  echo Не найдена Java. Установи Android Studio в папку по умолчанию.
  pause & exit /b 1
)
if not exist node_modules (call npm install || goto err)
call npm run vendor || goto err
if not exist android (call npx cap add android || goto err)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\android-permissions.ps1" || goto err
call npx cap sync android || goto err
cd android
call gradlew.bat assembleDebug || goto err
cd ..
copy /y "android\app\build\outputs\apk\debug\app-debug.apk" "BiletKart.apk" >nul
echo.
echo Готово! Файл приложения: %~dp0BiletKart.apk
echo Скинь его на телефон и установи.
pause
exit /b 0
:err
echo.
echo Сборка не удалась. Сделай скриншот этого окна и пришли в чат.
pause
exit /b 1
