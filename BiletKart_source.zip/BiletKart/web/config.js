// Настройки приложения БилетКарт.
// apiBase — адрес сервера. Пустая строка: тот же адрес, откуда открыт сайт
// (так и работает, когда server.py раздаёт сайт сам).
// appApiBase — адрес сервера для приложения Android: впиши сюда адрес с хостинга.
window.BK_CONFIG = {
  apiBase: "",
  appApiBase: "https://YOUR-SERVER.onrender.com",
};
if (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) {
  window.BK_CONFIG.apiBase = window.BK_CONFIG.appApiBase;
}
