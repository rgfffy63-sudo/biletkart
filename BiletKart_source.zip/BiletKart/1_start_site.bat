@echo off
chcp 65001 >nul
title BiletKart server
cd /d "%~dp0server"
where python >nul 2>nul || (echo Python не найден. Переустанови Python с галочкой "Add python.exe to PATH". & pause & exit /b 1)
echo Запускаю БилетКарт: http://localhost:8000
echo Чтобы остановить сервер, закрой это окно.
start "" /b powershell -NoProfile -Command "for($i=0;$i -lt 40;$i++){try{Invoke-WebRequest -UseBasicParsing http://localhost:8000/api/health -TimeoutSec 1 | Out-Null; Start-Process 'http://localhost:8000'; break}catch{Start-Sleep -Milliseconds 500}}"
python server.py
pause
