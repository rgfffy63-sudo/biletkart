@echo off
chcp 65001 >nul
title BiletKart: libraries
cd /d "%~dp0"
echo Скачиваю библиотеки (формулы, схемы, PDF, Word, Capacitor). Это займёт пару минут...
call npm install || goto err
call npm run vendor || goto err
echo.
echo Готово. Теперь приложение работает и без интернета.
pause
exit /b 0
:err
echo.
echo Что-то пошло не так. Сделай скриншот этого окна и пришли в чат.
pause
exit /b 1
