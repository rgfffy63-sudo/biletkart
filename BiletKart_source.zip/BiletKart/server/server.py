"""
БилетКарт — сервер.

Работает на чистом Python 3.10+ без сторонних библиотек:
  * раздаёт сайт/приложение из папки ../web
  * аккаунты (email + пароль), токены входа
  * подписка Pro (активация промокодом; место для подключения оплаты)
  * синхронизация колод между устройствами (только Pro)
  * «прокладка» к нейросетям: OpenAI-совместимые (DeepSeek, OpenAI, OpenRouter,
    Groq, Mistral, Qwen, Ollama…), Claude (Anthropic) и Gemini.
    Ключ пользователя пересылается провайдеру и НИГДЕ не сохраняется.

Запуск:  python server.py           (по умолчанию http://localhost:8000)
Настройки — переменные окружения, см. .env.example
"""
import base64, hashlib, hmac, ipaddress, json, os, re, secrets, socket, sqlite3, sys, threading, time
import urllib.error, urllib.parse, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

# ---------------------------------------------------------------- настройки
def load_env_file():
    p = Path(__file__).with_name(".env")
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())
load_env_file()

PORT = int(os.environ.get("PORT", "8000"))
HOST = os.environ.get("HOST", "0.0.0.0")
DB_PATH = os.environ.get("DB_PATH", str(Path(__file__).with_name("biletkart.db")))
WEB_DIR = Path(os.environ.get("WEB_DIR", str(Path(__file__).resolve().parent.parent / "web")))
# Промокоды: "КОД:дней,КОД2:дней". Если не задано — для локальной разработки работает DEMO-PRO на 30 дней.
PROMO_CODES = {}
for part in os.environ.get("PROMO_CODES", "DEMO-PRO:30").split(","):
    if ":" in part:
        c, d = part.split(":", 1)
        if c.strip() and d.strip().isdigit():
            PROMO_CODES[c.strip().upper()] = int(d)
ALLOW_LOCAL_AI = os.environ.get("ALLOW_LOCAL_AI", "0") == "1"   # разрешить адреса вида localhost (Ollama) — только для локального запуска
CORS_ORIGINS = [o.strip() for o in os.environ.get("CORS_ORIGINS", "*").split(",") if o.strip()]
# Встроенный ИИ для Pro (необязательно): провайдер/модель/ключ владельца сервиса
SERVER_AI = {
    "provider": os.environ.get("SERVER_AI_PROVIDER", ""),
    "model": os.environ.get("SERVER_AI_MODEL", ""),
    "key": os.environ.get("SERVER_AI_KEY", ""),
    "base_url": os.environ.get("SERVER_AI_BASE_URL", ""),
}
SERVER_AI_ON = bool(SERVER_AI["provider"] and SERVER_AI["key"])
MAX_BODY = 12 * 1024 * 1024
MAX_DOC = 2 * 1024 * 1024

# Тарифы: что открывает Pro. Меняется здесь.
PLAN_FEATURES = {
    "free": ["cards", "review", "materials", "ai_own_key", "stats", "backup"],
    "pro": ["cards", "review", "materials", "ai_own_key", "stats", "backup", "sync", "exam", "audio", "server_ai"],
}

# ---------------------------------------------------------------- провайдеры ИИ
# Названия моделей у провайдеров меняются: здесь только подсказки по умолчанию, пользователь может вписать свою.
PROVIDERS = {
    "deepseek":   {"title": "DeepSeek",   "kind": "openai", "base_url": "https://api.deepseek.com/v1", "model": "deepseek-chat", "vision": False},
    "openai":     {"title": "OpenAI",     "kind": "openai", "base_url": "https://api.openai.com/v1", "model": "gpt-4o-mini", "vision": True},
    "anthropic":  {"title": "Claude (Anthropic)", "kind": "anthropic", "base_url": "https://api.anthropic.com/v1", "model": "claude-haiku-5-5", "vision": True},
    "gemini":     {"title": "Google Gemini", "kind": "gemini", "base_url": "https://generativelanguage.googleapis.com/v1beta", "model": "gemini-2.5-flash", "vision": True},
    "openrouter": {"title": "OpenRouter (любые модели одним ключом)", "kind": "openai", "base_url": "https://openrouter.ai/api/v1", "model": "deepseek/deepseek-chat", "vision": False},
    "groq":       {"title": "Groq", "kind": "openai", "base_url": "https://api.groq.com/openai/v1", "model": "llama-3.3-70b-versatile", "vision": False},
    "mistral":    {"title": "Mistral", "kind": "openai", "base_url": "https://api.mistral.ai/v1", "model": "mistral-small-latest", "vision": False},
    "custom":     {"title": "Другой (совместимый с OpenAI API)", "kind": "openai", "base_url": "", "model": "", "vision": False},
}

class ApiError(Exception):
    def __init__(self, status, code, message):
        super().__init__(message); self.status = status; self.code = code; self.message = message

def check_url(url):
    """Защита от запросов во внутреннюю сеть сервера (SSRF)."""
    u = urllib.parse.urlparse(url)
    if u.scheme not in ("https", "http") or not u.hostname:
        raise ApiError(400, "bad_url", "Адрес API должен начинаться с https://")
    if ALLOW_LOCAL_AI:
        return
    if u.scheme != "https":
        raise ApiError(400, "bad_url", "Нужен адрес https://")
    try:
        infos = socket.getaddrinfo(u.hostname, u.port or 443)
    except socket.gaierror:
        raise ApiError(400, "bad_url", "Не удалось найти сервер по этому адресу")
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
            raise ApiError(400, "bad_url", "Локальные адреса запрещены на этом сервере")

def http_json(url, payload, headers, timeout=120):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST", headers={"Content-Type": "application/json", "User-Agent": "BiletKart/1.0", **headers})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")[:600]
        msg = body
        try:
            j = json.loads(body); err = j.get("error", j)
            msg = err.get("message") if isinstance(err, dict) else str(err)
        except Exception:
            pass
        if e.code in (401, 403):
            raise ApiError(400, "bad_key", "Провайдер отклонил ключ: " + (msg or "неверный ключ"))
        if e.code == 402:
            raise ApiError(402, "no_balance", "На счёте у провайдера закончились деньги. Пополни баланс в его личном кабинете или выбери другого провайдера в профиле")
        if e.code == 429:
            raise ApiError(429, "provider_limit", "У провайдера закончился лимит или баланс: " + (msg or ""))
        if e.code == 404:
            raise ApiError(400, "bad_model", "Модель или адрес не найдены: " + (msg or ""))
        raise ApiError(502, "provider_error", f"Ошибка провайдера ({e.code}): {msg}")
    except urllib.error.URLError as e:
        raise ApiError(502, "provider_unreachable", f"Провайдер недоступен: {e.reason}")
    except socket.timeout:
        raise ApiError(504, "provider_timeout", "Провайдер слишком долго отвечает")

def split_data_url(u):
    m = re.match(r"^data:(image/(?:png|jpeg|webp|gif));base64,([A-Za-z0-9+/=]+)$", u or "")
    if not m:
        raise ApiError(400, "bad_image", "Неверный формат изображения")
    return m.group(1), m.group(2)

def call_ai(provider, model, key, base_url, prompt, images=None, max_tokens=4000):
    p = PROVIDERS.get(provider)
    if not p:
        raise ApiError(400, "bad_provider", "Неизвестный провайдер")
    base = (base_url or p["base_url"]).rstrip("/")
    model = model or p["model"]
    if not base or not model:
        raise ApiError(400, "bad_config", "Укажи адрес API и название модели")
    if not key and provider != "custom":
        raise ApiError(400, "no_key", "Не указан API-ключ")
    check_url(base)
    images = images or []
    if p["kind"] == "anthropic":
        content = [{"type": "image", "source": {"type": "base64", "media_type": mt, "data": d}} for mt, d in map(split_data_url, images)]
        content.append({"type": "text", "text": prompt})
        j = http_json(base + "/messages", {"model": model, "max_tokens": max_tokens, "messages": [{"role": "user", "content": content}]},
                      {"x-api-key": key, "anthropic-version": "2023-06-01"})
        text = "".join(b.get("text", "") for b in j.get("content", []) if b.get("type") == "text")
    elif p["kind"] == "gemini":
        parts = [{"inline_data": {"mime_type": mt, "data": d}} for mt, d in map(split_data_url, images)]
        parts.append({"text": prompt})
        j = http_json(f"{base}/models/{urllib.parse.quote(model)}:generateContent",
                      {"contents": [{"role": "user", "parts": parts}], "generationConfig": {"maxOutputTokens": max_tokens}},
                      {"x-goog-api-key": key})
        cands = j.get("candidates") or []
        text = "".join(pt.get("text", "") for pt in (cands[0].get("content", {}).get("parts", []) if cands else []))
    else:
        if images:
            content = [{"type": "text", "text": prompt}] + [{"type": "image_url", "image_url": {"url": u}} for u in images]
        else:
            content = prompt
        headers = {"Authorization": "Bearer " + key} if key else {}
        if provider == "openrouter":
            headers.update({"HTTP-Referer": "https://biletkart.app", "X-Title": "BiletKart"})
        j = http_json(base + "/chat/completions", {"model": model, "max_tokens": max_tokens, "messages": [{"role": "user", "content": content}]}, headers)
        ch = j.get("choices") or []
        msg = ch[0].get("message", {}) if ch else {}
        text = msg.get("content") or ""
        if isinstance(text, list):
            text = "".join(x.get("text", "") for x in text if isinstance(x, dict))
    text = (text or "").strip()
    if not text:
        raise ApiError(502, "empty", "Нейросеть вернула пустой ответ")
    return text

# ---------------------------------------------------------------- база данных
_db_lock = threading.Lock()
def db():
    con = sqlite3.connect(DB_PATH, timeout=10, check_same_thread=False)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with _db_lock, db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, name TEXT, pw TEXT NOT NULL,
            pro_until REAL DEFAULT 0, created REAL);
        CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id INTEGER NOT NULL, created REAL);
        CREATE TABLE IF NOT EXISTS docs(user_id INTEGER NOT NULL, key TEXT NOT NULL, body TEXT NOT NULL, updated REAL,
            PRIMARY KEY(user_id, key));
        CREATE TABLE IF NOT EXISTS redeemed(user_id INTEGER, code TEXT, at REAL, PRIMARY KEY(user_id, code));
        """)

def hash_pw(pw, salt=None):
    salt = salt or secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 200_000).hex()
    return f"{salt}${h}"

def check_pw(pw, stored):
    salt, h = stored.split("$", 1)
    return hmac.compare_digest(hash_pw(pw, salt).split("$", 1)[1], h)

def user_public(u):
    pro = (u["pro_until"] or 0) > time.time()
    plan = "pro" if pro else "free"
    return {"id": u["id"], "email": u["email"], "name": u["name"] or "", "plan": plan,
            "pro_until": u["pro_until"] if pro else None, "features": PLAN_FEATURES[plan],
            "server_ai": SERVER_AI_ON and pro}

# ---------------------------------------------------------------- ограничение частоты
_rate = {}
def rate_limit(key, per_min):
    now = time.time()
    with _db_lock:
        arr = [t for t in _rate.get(key, []) if now - t < 60]
        if len(arr) >= per_min:
            raise ApiError(429, "rate_limited", "Слишком много запросов, подожди минуту")
        arr.append(now); _rate[key] = arr

# ---------------------------------------------------------------- HTTP
MIME = {".html": "text/html; charset=utf-8", ".js": "application/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
        ".json": "application/json", ".webmanifest": "application/manifest+json", ".png": "image/png", ".svg": "image/svg+xml",
        ".ico": "image/x-icon", ".woff2": "font/woff2", ".woff": "font/woff", ".ttf": "font/ttf", ".map": "application/json"}

class Handler(BaseHTTPRequestHandler):
    server_version = "BiletKart/1.0"

    def log_message(self, fmt, *args):  # без тел запросов — ключи не попадают в логи
        sys.stderr.write("%s %s\n" % (self.command, self.path.split("?")[0]))

    def cors(self):
        origin = self.headers.get("Origin")
        if "*" in CORS_ORIGINS:
            self.send_header("Access-Control-Allow-Origin", "*")
        elif origin and origin in CORS_ORIGINS:
            self.send_header("Access-Control-Allow-Origin", origin); self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")

    def send_json(self, status, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.cors(); self.end_headers(); self.wfile.write(body)

    def body_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > MAX_BODY:
            raise ApiError(413, "too_large", "Слишком большой запрос")
        raw = self.rfile.read(n) if n else b"{}"
        try:
            v = json.loads(raw.decode("utf-8") or "{}")
        except Exception:
            raise ApiError(400, "bad_json", "Неверный JSON")
        if not isinstance(v, dict):
            raise ApiError(400, "bad_json", "Ожидался объект JSON")
        return v

    def client_ip(self):
        return (self.headers.get("X-Forwarded-For") or self.client_address[0]).split(",")[0].strip()

    def current_user(self, required=True):
        auth = self.headers.get("Authorization", "")
        tok = auth[7:] if auth.startswith("Bearer ") else ""
        if tok:
            with db() as con:
                row = con.execute("SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=?", (tok,)).fetchone()
            if row:
                return row
        if required:
            raise ApiError(401, "auth", "Нужно войти в аккаунт")
        return None

    def do_OPTIONS(self):
        self.send_response(204); self.cors(); self.end_headers()

    def do_GET(self): self.dispatch("GET")
    def do_POST(self): self.dispatch("POST")
    def do_PUT(self): self.dispatch("PUT")
    def do_DELETE(self): self.dispatch("DELETE")

    def dispatch(self, method):
        path = urllib.parse.urlparse(self.path).path
        try:
            if path.startswith("/api/"):
                return self.api(method, path)
            if method != "GET":
                raise ApiError(405, "method", "Метод не поддерживается")
            return self.static(path)
        except ApiError as e:
            self.send_json(e.status, {"error": e.code, "message": e.message})
        except Exception as e:
            sys.stderr.write(f"ERROR {type(e).__name__}: {e}\n")
            self.send_json(500, {"error": "server", "message": "Внутренняя ошибка сервера"})

    def static(self, path):
        rel = urllib.parse.unquote(path).lstrip("/") or "index.html"
        f = (WEB_DIR / rel).resolve()
        if not str(f).startswith(str(WEB_DIR.resolve())) or not f.is_file():
            if Path(rel).suffix:  # нет такого файла (например, библиотеки не скопированы) — честный 404
                raise ApiError(404, "not_found", "Файл не найден")
            f = WEB_DIR / "index.html"  # одностраничное приложение
        data = f.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", MIME.get(f.suffix.lower(), "application/octet-stream"))
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache" if f.suffix in (".html", ".js", ".webmanifest") else "public, max-age=86400")
        self.end_headers(); self.wfile.write(data)

    # ------------------------------------------------------------ API
    def api(self, method, path):
        r = (method, path)
        if r == ("GET", "/api/health"):
            return self.send_json(200, {"ok": True})
        if r == ("GET", "/api/config"):
            return self.send_json(200, {"providers": {k: {kk: vv for kk, vv in v.items()} for k, v in PROVIDERS.items()},
                                        "plans": PLAN_FEATURES, "server_ai": SERVER_AI_ON})

        if r == ("POST", "/api/auth/register"):
            rate_limit("reg:" + self.client_ip(), 10)
            b = self.body_json()
            email = str(b.get("email", "")).strip().lower(); pw = str(b.get("password", "")); name = str(b.get("name", "")).strip()[:60]
            if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email):
                raise ApiError(400, "bad_email", "Проверь email")
            if len(pw) < 6:
                raise ApiError(400, "weak_pw", "Пароль — минимум 6 символов")
            with _db_lock, db() as con:
                if con.execute("SELECT 1 FROM users WHERE email=?", (email,)).fetchone():
                    raise ApiError(409, "exists", "Аккаунт с таким email уже есть")
                cur = con.execute("INSERT INTO users(email,name,pw,created) VALUES(?,?,?,?)", (email, name, hash_pw(pw), time.time()))
                tok = secrets.token_urlsafe(32)
                con.execute("INSERT INTO sessions VALUES(?,?,?)", (tok, cur.lastrowid, time.time()))
                u = con.execute("SELECT * FROM users WHERE id=?", (cur.lastrowid,)).fetchone()
            return self.send_json(200, {"token": tok, "user": user_public(u)})

        if r == ("POST", "/api/auth/login"):
            rate_limit("login:" + self.client_ip(), 20)
            b = self.body_json()
            email = str(b.get("email", "")).strip().lower(); pw = str(b.get("password", ""))
            with _db_lock, db() as con:
                u = con.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
                if not u or not check_pw(pw, u["pw"]):
                    raise ApiError(401, "bad_login", "Неверный email или пароль")
                tok = secrets.token_urlsafe(32)
                con.execute("INSERT INTO sessions VALUES(?,?,?)", (tok, u["id"], time.time()))
            return self.send_json(200, {"token": tok, "user": user_public(u)})

        if r == ("POST", "/api/auth/logout"):
            auth = self.headers.get("Authorization", "")
            with _db_lock, db() as con:
                con.execute("DELETE FROM sessions WHERE token=?", (auth[7:],))
            return self.send_json(200, {"ok": True})

        if r == ("GET", "/api/me"):
            return self.send_json(200, {"user": user_public(self.current_user())})

        if r == ("POST", "/api/billing/redeem"):
            u = self.current_user()
            rate_limit("promo:" + str(u["id"]), 10)
            code = str(self.body_json().get("code", "")).strip().upper()
            days = PROMO_CODES.get(code)
            if not days:
                raise ApiError(400, "bad_code", "Такого промокода нет")
            with _db_lock, db() as con:
                if con.execute("SELECT 1 FROM redeemed WHERE user_id=? AND code=?", (u["id"], code)).fetchone():
                    raise ApiError(400, "used_code", "Этот промокод уже активирован")
                start = max(time.time(), u["pro_until"] or 0)
                con.execute("UPDATE users SET pro_until=? WHERE id=?", (start + days * 86400, u["id"]))
                con.execute("INSERT INTO redeemed VALUES(?,?,?)", (u["id"], code, time.time()))
                u = con.execute("SELECT * FROM users WHERE id=?", (u["id"],)).fetchone()
            return self.send_json(200, {"user": user_public(u)})

        if path.startswith("/api/sync"):
            u = self.current_user()
            if user_public(u)["plan"] != "pro":
                raise ApiError(402, "need_pro", "Синхронизация доступна в Pro")
            if r == ("GET", "/api/sync"):
                with db() as con:
                    rows = con.execute("SELECT key, body, updated FROM docs WHERE user_id=?", (u["id"],)).fetchall()
                return self.send_json(200, {"docs": [{"key": x["key"], "body": json.loads(x["body"]), "updated": x["updated"]} for x in rows]})
            m = re.match(r"^/api/sync/([A-Za-z0-9_.:-]{1,120})$", path)
            if not m:
                raise ApiError(404, "not_found", "Нет такого адреса")
            key = m.group(1)
            if method == "PUT":
                rate_limit("sync:" + str(u["id"]), 240)
                raw = self.body_json()
                body = json.dumps(raw, ensure_ascii=False)
                if len(body) > MAX_DOC:
                    raise ApiError(413, "too_large", "Документ слишком большой")
                with _db_lock, db() as con:
                    if con.execute("SELECT COUNT(*) FROM docs WHERE user_id=?", (u["id"],)).fetchone()[0] > 3000:
                        raise ApiError(413, "quota", "Слишком много документов")
                    con.execute("INSERT INTO docs VALUES(?,?,?,?) ON CONFLICT(user_id,key) DO UPDATE SET body=excluded.body, updated=excluded.updated",
                                (u["id"], key, body, time.time()))
                return self.send_json(200, {"ok": True})
            if method == "DELETE":
                with _db_lock, db() as con:
                    con.execute("DELETE FROM docs WHERE user_id=? AND key=?", (u["id"], key))
                return self.send_json(200, {"ok": True})

        if r in (("POST", "/api/ai"), ("POST", "/api/ai/test")):
            b = self.body_json()
            u = self.current_user(required=False)
            use_server = bool(b.get("use_server_ai"))
            rate_limit("ai:" + (str(u["id"]) if u else self.client_ip()), 40)
            if use_server:
                if not (u and SERVER_AI_ON and user_public(u)["plan"] == "pro"):
                    raise ApiError(402, "need_pro", "Встроенный ИИ доступен в Pro")
                cfg = SERVER_AI
            else:
                cfg = {k: str(b.get(k, "") or "") for k in ("provider", "model", "key", "base_url")}
            if path.endswith("/test"):
                text = call_ai(cfg["provider"], cfg["model"], cfg["key"], cfg["base_url"], "Ответь одним словом: работает", max_tokens=20)
                return self.send_json(200, {"ok": True, "text": text[:100]})
            prompt = str(b.get("prompt", ""))
            if not prompt.strip():
                raise ApiError(400, "empty_prompt", "Пустой запрос")
            if len(prompt) > 300_000:
                raise ApiError(413, "too_large", "Слишком длинный запрос")
            images = [str(x) for x in (b.get("images") or [])][:4]
            if images and not PROVIDERS.get(cfg["provider"], {}).get("vision") and cfg["provider"] not in ("custom", "openrouter"):
                raise ApiError(400, "no_vision", "Эта модель не понимает изображения. Выбери Claude, OpenAI или Gemini")
            text = call_ai(cfg["provider"], cfg["model"], cfg["key"], cfg["base_url"], prompt, images, int(b.get("max_tokens") or 4000))
            return self.send_json(200, {"text": text})

        raise ApiError(404, "not_found", "Нет такого адреса")

def main():
    init_db()
    srv = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"БилетКарт запущен: http://localhost:{PORT}")
    print(f"  сайт из: {WEB_DIR}")
    print(f"  промокоды: {', '.join(PROMO_CODES) or 'нет'} · встроенный ИИ: {'включён' if SERVER_AI_ON else 'выключен'}")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nОстановлен")

if __name__ == "__main__":
    main()
