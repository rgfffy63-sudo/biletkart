#!/bin/sh
cat src/p1_head.html src/p2_core.js src/p3_demo.js src/p4_views.js src/p5_exam.js src/p6_actions.js src/p7_profile.js src/p8_boot.js > web/index.html
