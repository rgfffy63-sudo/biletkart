<script>
/* ============ модальные окна ============ */
function parseTicketList(text) {
  const out = []; let auto = 1;
  for (const raw of String(text).split(/\r?\n/)) {
    const line = raw.trim().replace(/^[-•*]\s+/, ""); if (!line) continue;
    const m = line.match(/^(?:билет|вопрос|тема)?\s*№?\s*(\d{1,3})\s*[.):\-–—|]?\s+(.{3,})$/i);
    if (m) { out.push({ num: +m[1], title: m[2].trim() }); auto = +m[1] + 1; }
    else if (line.length > 3) out.push({ num: auto++, title: line });
  }
  return out;
}
function addTickets(d, list) {
  let add = 0, skip = 0;
  for (const it of list) { if (d.tickets.some(t => t.num === it.num)) { skip++; continue; } d.tickets.push({ id: "t" + uid(), num: it.num, title: it.title }); add++; }
  touch("deck-" + d.id); return { add, skip };
}
function modalNewDeck() {
  const m = openModal(`<div class="modal-h"><div><div class="eyebrow">новая колода</div><h2>Предмет</h2></div><button class="ib" data-act="close" aria-label="Закрыть">✕</button></div>
    <div class="stack"><div><label class="lbl" for="ndName">Название</label><input type="text" id="ndName" placeholder="Например, Гражданское право" autofocus></div>
    <div><label class="lbl" for="ndList">Список билетов (можно позже)</label><textarea id="ndList" rows="7" placeholder="1. Понятие и признаки юридического лица&#10;2. Сделки: виды и форма&#10;3. ..."></textarea><div class="mlab" id="ndCount"></div></div>
    <label class="switch"><input type="checkbox" id="ndStrict" checked> Строго по материалам: ИИ не добавляет ничего от себя</label></div>
    <div class="modal-f"><button class="btn ghost" data-act="close">Отмена</button><button class="btn pri" id="ndOk">Создать</button></div>`);
  const upd = () => { const n = parseTicketList($("#ndList", m).value).length; $("#ndCount", m).textContent = n ? "распознано: " + pl(n, "билет", "билета", "билетов") : ""; };
  $("#ndList", m).addEventListener("input", upd);
  $("#ndOk", m).onclick = () => {
    const name = $("#ndName", m).value.trim(); if (!name) { $("#ndName", m).focus(); return; }
    const id = "d" + uid(); const d = { id, name, strict: $("#ndStrict", m).checked, createdAt: Date.now(), tickets: [], cards: [] };
    S.decks[id] = d; S.meta.order.unshift(id); addTickets(d, parseTicketList($("#ndList", m).value)); touch("meta");
    closeModal(); UI.tab = d.tickets.length ? "mats" : "tickets"; go("deck", id);
  };
}
function modalDeckSettings(d) {
  const m = openModal(`<div class="modal-h"><div><div class="eyebrow">настройки колоды</div><h2>${esc(d.name)}</h2></div><button class="ib" data-act="close" aria-label="Закрыть">✕</button></div>
    <div class="stack"><div><label class="lbl" for="dsName">Название</label><input type="text" id="dsName" value="${esc(d.name)}"></div>
    <label class="switch"><input type="checkbox" id="dsStrict" ${d.strict ? "checked" : ""}> Строго по материалам</label>
    <p class="muted" style="margin:0;font-size:13px">Включено: ИИ берёт факты только из загруженных конспектов, а если ответа там нет, так и пишет. Выключено: может дополнять общими знаниями, такие карточки остаются без источника.</p>
    <div style="border-top:1px solid var(--line);padding-top:14px"><button class="btn danger" id="dsDel">${ICON.del} Удалить колоду</button></div></div>
    <div class="modal-f"><button class="btn ghost" data-act="close">Отмена</button><button class="btn pri" id="dsOk">Сохранить</button></div>`);
  $("#dsOk", m).onclick = () => { d.name = $("#dsName", m).value.trim() || d.name; d.strict = $("#dsStrict", m).checked; touch("deck-" + d.id); closeModal(); render(); };
  const del = $("#dsDel", m); let armed = false;
  del.onclick = () => {
    if (!armed) { armed = true; del.textContent = "Точно удалить вместе с карточками и материалами? Нажми ещё раз"; del.style.borderColor = "var(--bad)"; del.style.color = "var(--bad)"; return; }
    deckMaterials(d).forEach(mt => { delete S.materials[mt.id]; removed.add("mat-" + mt.id); dirty.delete("mat-" + mt.id); });
    delete S.decks[d.id]; removed.add("deck-" + d.id); dirty.delete("deck-" + d.id); S.meta.order = S.meta.order.filter(x => x !== d.id);
    touch("meta"); closeModal(); go("decks"); toast("Колода удалена");
  };
}
function modalImport(d) {
  const m = openModal(`<div class="modal-h"><div><div class="eyebrow">импорт билетов</div><h2>Список вопросов к экзамену</h2></div><button class="ib" data-act="close" aria-label="Закрыть">✕</button></div>
    <p class="muted" style="margin:0 0 10px;font-size:13.5px">Вставь список из методички: по одному билету в строке. Номера распознаются сами («1.», «Билет 2», «№3»).</p>
    <textarea id="imText" rows="10" autofocus placeholder="1. ...&#10;2. ..."></textarea><div class="mlab" id="imCount"></div>
    <div class="modal-f">${deckMaterials(d).length ? `<button class="btn ai" id="imAi" style="margin-right:auto">${ICON.spark} Найти билеты в материалах</button>` : ""}<button class="btn ghost" data-act="close">Отмена</button><button class="btn pri" id="imOk">Добавить</button></div>`);
  const ta = $("#imText", m), upd = () => { const n = parseTicketList(ta.value).length; $("#imCount", m).textContent = n ? "распознано: " + pl(n, "билет", "билета", "билетов") : ""; };
  ta.addEventListener("input", upd);
  $("#imOk", m).onclick = () => { const r = addTickets(d, parseTicketList(ta.value)); closeModal(); render(); toast(`Добавлено: ${r.add}${r.skip ? `, пропущено с повторным номером: ${r.skip}` : ""}`); };
  const aiB = $("#imAi", m);
  if (aiB) aiB.onclick = async () => {
    aiB.disabled = true; aiB.innerHTML = `<span class="spin"></span> Ищу…`;
    const txt = deckMaterials(d).flatMap(x => x.chunks).join("\n\n").slice(0, 24000);
    try {
      const out = await ai(`В тексте ниже — материалы студента по предмету «${d.name}». Найди в нём список экзаменационных вопросов или билетов. Если явного списка нет, сформулируй вопросы к экзамену по разделам материала (не больше 30). Выведи только строки вида «номер. формулировка», без пояснений.\n\n${txt}`, { tier: "quick" });
      ta.value = out.trim(); upd();
    } catch (e) { toast(aiErrText(e), "err"); }
    aiB.disabled = false; aiB.innerHTML = `${ICON.spark} Найти билеты в материалах`;
  };
}
function modalTicket(d, t) {
  const next = d.tickets.length ? Math.max(...d.tickets.map(x => x.num)) + 1 : 1;
  const m = openModal(`<div class="modal-h"><div><div class="eyebrow">${t ? "билет" : "новый билет"}</div><h2>${t ? "Билет №" + t.num : "Добавить билет"}</h2></div><button class="ib" data-act="close" aria-label="Закрыть">✕</button></div>
    <div class="row" style="align-items:flex-start"><div style="width:90px"><label class="lbl" for="tkNum">Номер</label><input type="number" id="tkNum" min="1" value="${t ? t.num : next}"></div>
    <div class="grow"><label class="lbl" for="tkTitle">Формулировка</label><textarea id="tkTitle" rows="3" autofocus>${t ? esc(t.title) : ""}</textarea></div></div>
    <div class="modal-f">${t ? `<button class="btn danger" id="tkDel" style="margin-right:auto">${ICON.del} Удалить билет</button>` : ""}<button class="btn ghost" data-act="close">Отмена</button><button class="btn pri" id="tkOk">Сохранить</button></div>`);
  $("#tkOk", m).onclick = () => {
    const num = parseInt($("#tkNum", m).value, 10), title = $("#tkTitle", m).value.trim(); if (!title || !num) return;
    if (d.tickets.some(x => x.num === num && x !== t)) { toast("Билет с таким номером уже есть", "err"); return; }
    if (t) { t.num = num; t.title = title; } else d.tickets.push({ id: "t" + uid(), num, title });
    touch("deck-" + d.id); closeModal(); render();
  };
  const del = $("#tkDel", m); let armed = false;
  if (del) del.onclick = () => { const n = d.cards.filter(c => c.t === t.id).length; if (!armed && n) { armed = true; del.textContent = `Удалить вместе с ${pl(n, "карточкой", "карточками", "карточками")}? Ещё раз`; return; } d.tickets = d.tickets.filter(x => x !== t); d.cards = d.cards.filter(c => c.t !== t.id); touch("deck-" + d.id); closeModal(); render(); };
}
const SNIPS = [
  ["\\(x\\)", "\\(", "\\)", "формула в строке"], ["\\[ \\]", "\n\\[\n", "\n\\]\n", "формула блоком"],
  ["дробь", "\\frac{", "}{}", "\\frac{a}{b}"], ["√", "\\sqrt{", "}", "корень"], ["∫", "\\int_{a}^{b} ", " \\,dx", "интеграл"], ["Σ", "\\sum_{n=1}^{\\infty} ", "", "сумма"],
  ["lim", "\\lim_{x\\to 0} ", "", "предел"], ["матрица", "\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}", "", "матрица 2×2"],
  ["H₂O", "\\ce{", "}", "химия: \\ce{2H2 + O2 -> 2H2O}"], ["код", "\n```python\n", "\n```\n", "блок кода"],
  ["схема", "\n```mermaid\nflowchart LR\n  A[Начало] --> B[Шаг] --> C[Итог]\n```\n", "", "схема Mermaid"], ["график", "\n```graph\ny = sin(x)\nx: -6..6\n```\n", "", "график функции"],
  ["таблица", "\n| Термин | Определение |\n|---|---|\n|  |  |\n", "", "таблица"], ["**Ж**", "**", "**", "жирный"],
];
function modalCard(d, card, tid) {
  const ts = sortedTickets(d); tid = card ? card.t : tid;
  const m = openModal(`<div class="modal-h"><div><div class="eyebrow">${card ? "редактор карточки" : "новая карточка"}</div><h2>${esc(d.name)}</h2></div><button class="ib" data-act="close" aria-label="Закрыть">✕</button></div>
    <div class="ed-grid"><div class="stack">
      <div><label class="lbl" for="ceT">Билет</label><select id="ceT">${ts.map(t => `<option value="${t.id}" ${t.id === tid ? "selected" : ""}>№${t.num}. ${esc(t.title.slice(0, 80))}</option>`).join("")}</select></div>
      <div class="ed-tools" role="toolbar" aria-label="Вставка">${SNIPS.map((s, i) => `<button type="button" data-snip="${i}" title="${esc(s[3])}">${esc(s[0])}</button>`).join("")}</div>
      <div><label class="lbl" for="ceQ">Вопрос</label><textarea id="ceQ" rows="3" autofocus>${card ? esc(card.q) : ""}</textarea></div>
      <div><label class="lbl" for="ceA">Ответ</label><textarea id="ceA" rows="10">${card ? esc(card.a) : ""}</textarea></div>
      <details><summary class="lbl" style="cursor:pointer">Шпаргалка по разметке</summary><div class="cheat">
        <code>\\( a^2+b^2=c^2 \\)</code><span>формула в строке (можно и $...$)</span><code>\\[ ... \\]</code><span>формула отдельной строкой</span>
        <code>\\ce{CH4 + 2O2 -> CO2 + 2H2O}</code><span>химическая реакция</span><code>\`\`\`python</code><span>код с подсветкой</span>
        <code>\`\`\`mermaid</code><span>схема: flowchart, sequenceDiagram</span><code>\`\`\`graph</code><span>график: строки y = ..., x: -5..5</span>
        <code>| a | b |</code><span>таблица Markdown</span></div></details>
    </div><div><div class="lbl">Предпросмотр</div><div class="preview" id="cePrev"></div></div></div>
    <div class="modal-f"><button class="btn ghost" data-act="close">Отмена</button><button class="btn pri" id="ceOk">Сохранить</button></div>`, { wide: true });
  const q = $("#ceQ", m), a = $("#ceA", m), prev = $("#cePrev", m); let last = a, tm = 0;
  const upd = () => { clearTimeout(tm); tm = setTimeout(() => { prev.innerHTML = `<div class="rich" style="font-weight:600;margin-bottom:10px">${renderRich(q.value || "_вопрос_")}</div><div class="rich" style="border-top:1px dashed var(--line2);padding-top:10px">${renderRich(a.value || "_ответ_")}</div>`; hydrate(prev); }, 280); };
  [q, a].forEach(el => { el.addEventListener("input", upd); el.addEventListener("focus", () => last = el); });
  $$("[data-snip]", m).forEach(b => b.onclick = () => { const s = SNIPS[+b.dataset.snip], el = last, st = el.selectionStart, en = el.selectionEnd, sel = el.value.slice(st, en); el.value = el.value.slice(0, st) + s[1] + sel + s[2] + el.value.slice(en); el.focus(); const pos = st + s[1].length + sel.length; el.setSelectionRange(pos, pos); upd(); });
  upd();
  $("#ceOk", m).onclick = () => {
    const qq = q.value.trim(), aa = a.value.trim(); if (!qq || !aa) { toast("Заполни вопрос и ответ", "err"); return; }
    if (card) { card.q = qq; card.a = aa; card.t = $("#ceT", m).value; }
    else d.cards.push({ id: "c" + uid(), t: $("#ceT", m).value, q: qq, a: aa, src: [], quote: "", check: [], ai: false, hist: [], reps: 0, ivl: 0, ease: 2.5, due: 0, createdAt: Date.now() });
    UI.open.add($("#ceT", m).value); touch("deck-" + d.id); closeModal(); render();
  };
}
function findCard(cid) { for (const d of deckList()) { const c = d.cards.find(x => x.id === cid); if (c) return { d, c }; } return null; }
function modalSrc(cid, cardId) {
  const ch = chunkById(cid); const fc = cardId && findCard(cardId); const quote = fc ? fc.c.quote : "";
  let body = ch ? esc(ch.text) : "Фрагмент не найден: материал удалён.";
  if (ch && quote) { const qn = esc(quote.trim()); const i = body.toLowerCase().indexOf(qn.toLowerCase()); if (i >= 0 && qn.length > 4) body = body.slice(0, i) + "<mark>" + body.slice(i, i + qn.length) + "</mark>" + body.slice(i + qn.length); }
  openModal(`<div class="modal-h"><div><div class="eyebrow m">источник ответа</div><h2>${ch ? esc(ch.mat.name) + " · ¶" + (ch.n + 1) : "Источник"}</h2></div><button class="ib" data-act="close" aria-label="Закрыть">✕</button></div>
    <div class="frag">${body}</div>${quote ? `<p class="muted" style="font-size:12.5px;margin:12px 0 0">Подсвечена цитата, на которую опирается ИИ. Если её нет в тексте, ответ стоит перепроверить.</p>` : ""}
    <div class="modal-f">${ch ? `<button class="btn" data-act="view-mat" data-mid="${ch.mat.id}" data-n="${ch.n}">Открыть весь материал</button>` : ""}<button class="btn pri" data-act="close">Понятно</button></div>`);
}
function modalMat(mid, focusN) {
  const mt = S.materials[mid]; if (!mt) return;
  const m = openModal(`<div class="modal-h"><div><div class="eyebrow">материал</div><h2>${esc(mt.name)}</h2></div><button class="ib" data-act="close" aria-label="Закрыть">✕</button></div>
    <div class="stack">${mt.chunks.map((c, n) => `<div id="mch${n}"><div class="mono" style="font-size:11px;color:${n === focusN ? "var(--pink)" : "var(--dim)"}">¶${n + 1}</div><div class="frag" style="border-left-color:${n === focusN ? "var(--pink)" : "var(--line2)"}">${esc(c)}</div></div>`).join("")}</div>
    <div class="modal-f"><button class="btn pri" data-act="close">Закрыть</button></div>`, { wide: true });
  if (focusN != null) setTimeout(() => $("#mch" + focusN, m)?.scrollIntoView({ block: "center" }), 50);
}
function modalPaste(d) {
  const m = openModal(`<div class="modal-h"><div><div class="eyebrow">материал</div><h2>Вставить текст</h2></div><button class="ib" data-act="close" aria-label="Закрыть">✕</button></div>
    <div class="stack"><div><label class="lbl" for="pmName">Название</label><input type="text" id="pmName" value="Конспект"></div><div><label class="lbl" for="pmText">Текст</label><textarea id="pmText" rows="12" autofocus placeholder="Скопируй сюда лекцию, ответы из чата или текст из Telegram"></textarea></div></div>
    <div class="modal-f"><button class="btn ghost" data-act="close">Отмена</button><button class="btn pri" id="pmOk">Добавить</button></div>`);
  $("#pmOk", m).onclick = () => { const n = addMaterialText(d, $("#pmName", m).value.trim() || "Конспект", "TXT", $("#pmText", m).value); if (n) { closeModal(); render(); toast(pl(n, "фрагмент добавлен", "фрагмента добавлено", "фрагментов добавлено")); } };
}

/* ============ действия (делегирование кликов) ============ */
let _lastDel = null;
const ACT = {
  close: () => closeModal(),
  "new-deck": () => modalNewDeck(),
  "open-deck": el => go("deck", el.dataset.deck),
  "start-review": () => { RVSET.mode = "due"; startReview(deckList().map(d => d.id), "due", RVSET.method); },
  "review-deck": el => { RVSET.decks = [el.dataset.deck]; startReview([el.dataset.deck], "due", RVSET.method); },
  "exam-deck": el => { EXSET.deckId = el.dataset.deck; EX = null; go("exam"); },
  "deck-settings": () => modalDeckSettings(S.decks[UI.deckId]),
  tab: el => { UI.tab = el.dataset.tab; render(); },
  "import-tickets": () => modalImport(S.decks[UI.deckId]),
  "add-ticket": () => modalTicket(S.decks[UI.deckId], null),
  "edit-ticket": el => { const d = S.decks[UI.deckId]; modalTicket(d, ticketOf(d, el.dataset.tid)); },
  "toggle-ticket": el => { const id = el.dataset.tid; UI.open.has(id) ? UI.open.delete(id) : UI.open.add(id); render(); },
  "gen-ticket": async el => { try { const n = await genTicket(UI.deckId, el.dataset.tid); toast(n ? `ИИ создал ${pl(n, "карточку", "карточки", "карточек")}` : "Карточки не созданы, причина под билетом", n ? "ai" : "err"); if (!n) { UI.open.add(el.dataset.tid); render(); } } catch (e) { if (e.code !== "cancelled") toast(aiErrText(e), "err"); } },
  "gen-all": () => genAll(S.decks[UI.deckId]),
  "batch-stop": () => { if (BATCH) BATCH.ctl.abort(); },
  "add-card": el => modalCard(S.decks[UI.deckId], null, el.dataset.tid),
  "edit-card": el => { const f = findCard(el.dataset.cid); if (f) modalCard(f.d, f.c); },
  "del-card": el => { const f = findCard(el.dataset.cid); if (!f) return; const i = f.d.cards.indexOf(f.c); f.d.cards.splice(i, 1); _lastDel = { d: f.d, c: f.c, i }; touch("deck-" + f.d.id); render(); toast("Карточка удалена", "", { label: "Вернуть", fn: () => { if (_lastDel) { _lastDel.d.cards.splice(_lastDel.i, 0, _lastDel.c); touch("deck-" + _lastDel.d.id); _lastDel = null; render(); } } }); },
  "show-src": el => modalSrc(el.dataset.cid, el.dataset.card),
  "view-mat": el => modalMat(el.dataset.mid, el.dataset.n != null ? +el.dataset.n : null),
  "del-mat": el => { const mt = S.materials[el.dataset.mid]; if (!mt) return; delete S.materials[mt.id]; removed.add("mat-" + mt.id); dirty.delete("mat-" + mt.id); saveLocalSoon(); saveCloudSoon(); render(); toast(`«${mt.name}» удалён`, "", { label: "Вернуть", fn: () => { S.materials[mt.id] = mt; removed.delete("mat-" + mt.id); touch("mat-" + mt.id); render(); } }); },
  "paste-mat": () => modalPaste(S.decks[UI.deckId]),
  mic: el => toggleMic(el),
  speak: el => { const cur = rvCur(); if (!cur) return; speak(el.dataset.what === "qa" ? cur.c.q + ". Ответ. " + cur.c.a : cur.c.q, el); },
  explain: () => explainCard(),
  "rv-deck": el => { const id = el.dataset.deck, s = new Set(RVSET.decks); s.has(id) ? s.delete(id) : s.add(id); RVSET.decks = Array.from(s); render(); },
  "rv-mode": el => { RVSET.mode = el.dataset.mode; render(); },
  "rv-method": el => { RVSET.method = el.dataset.method; render(); },
  "rv-start": () => startReview(RVSET.decks.filter(id => S.decks[id]), RVSET.mode, RVSET.method),
  "rv-reveal": () => { if (RV) { RV.answer = ($("#rvAns")?.value || "").trim(); RV.revealed = true; render(); } },
  "rv-check": () => rvCheck(),
  "rv-grade": el => rvGrade(+el.dataset.g),
  "rv-exit": () => { RV = null; render(); },
  "rv-weak-again": () => startReview(RV ? RV.deckIds : deckList().map(d => d.id), "weak", RV ? RV.method : RVSET.method),
  "weak-all": () => startReview(deckList().map(d => d.id), "weak", RVSET.method),
  "audio-run": () => audioRun(),
  "open-ticket": el => { UI.open.add(el.dataset.tid); UI.tab = "tickets"; go("deck", el.dataset.deck); setTimeout(() => $("#tr-" + el.dataset.tid)?.scrollIntoView({ block: "center" }), 60); },
  "ex-deck": el => { EXSET.deckId = el.dataset.deck; GEN = null; if (EXSET.k > S.decks[el.dataset.deck].tickets.length) EXSET.k = 1; render(); },
  "ex-min": el => { EXSET.minutes = +el.dataset.v; render(); },
  "ex-k": el => { EXSET.k = +el.dataset.v; render(); },
  "gen-k": el => { GENSET.k = +el.dataset.v; GENSET.n = clamp(parseInt($("#genN")?.value, 10) || GENSET.n, 2, 40); render(); },
  "ex-draw": () => { if (EX && EX.state === "done") EXSET.deckId = EX.deckId; drawTicket(); },
  "ex-submit": () => submitExam(),
  "ex-cancel": () => { EX = null; clearInterval(_exTimer); render(); },
  "ex-self": () => { EX.state = "self"; render(); },
  "ex-selfmark": el => { const mk = +el.dataset.v, d = S.decks[EX.deckId]; saveExam(d, null, Math.round((mk - 2) / 3 * 100), mk); EX.res = { items: [], total: Math.round((mk - 2) / 3 * 100), mark: mk, comment: "Самооценка без ИИ.", extra: "" }; EX.state = "done"; render(); },
  "ex-extra": () => extraAnswer(),
  "ex-finish": () => { EX.state = "done"; render(); },
  "gen-set": () => genSet(true),
  "gen-local": () => genSet(false),
  "gen-copy": () => { if (!GEN || !GEN.list) return; const txt = `${exDeck().name}\n\n` + GEN.list.map((t, i) => `Билет №${i + 1}\n` + t.map((q, j) => `${j + 1}. ${q}`).join("\n")).join("\n\n"); navigator.clipboard.writeText(txt).then(() => toast("Скопировано")).catch(() => { openModal(`<div class="modal-h"><h2>Скопируй вручную</h2><button class="ib" data-act="close" aria-label="Закрыть">✕</button></div><textarea rows="16" readonly>${esc(txt)}</textarea>`); }); },
};
document.addEventListener("click", e => {
  const nav = e.target.closest("[data-nav]"); if (nav) { go(nav.dataset.nav); return; }
  const a = e.target.closest("[data-act]"); if (!a || a.disabled) return;
  const fn = ACT[a.dataset.act]; if (!fn) return;
  if (a.tagName === "ARTICLE" && e.target.closest("button,a,input") && e.target.closest("button,a,input") !== a) return;
  e.preventDefault(); fn(a, e);
});
document.addEventListener("keydown", e => {
  if (e.key === "Escape" && $("#modalRoot").firstChild) { closeModal(); return; }
  if ($("#modalRoot").firstChild) return;
  const tgt = e.target, typing = tgt.matches && tgt.matches("textarea,input,select");
  if (e.key === "Enter" && tgt.matches && tgt.matches("article[data-act]")) { ACT["open-deck"](tgt); return; }
  if (UI.view === "review" && RV && rvCur()) {
    if (tgt.id === "rvAns" && e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); rvCheck(); return; }
    if (typing) return;
    if (e.key === " " && !RV.revealed) { e.preventDefault(); ACT["rv-reveal"](); }
    else if (RV.revealed && ["1", "2", "3", "4"].includes(e.key)) rvGrade(+e.key - 1);
  }
});
document.addEventListener("input", e => { if (e.target.id === "tq") { UI.q = e.target.value; const pos = e.target.selectionStart; render(); const el = $("#tq"); if (el) { el.focus(); el.setSelectionRange(pos, pos); } } });
document.addEventListener("change", e => {
  if (e.target.id === "fileIn" && e.target.files.length) addFiles(S.decks[UI.deckId], e.target.files);
  if (e.target.id === "exTask") EXSET.task = e.target.checked;
  if (e.target.id === "genTask") GENSET.task = e.target.checked;
  if (e.target.id === "genN") GENSET.n = clamp(parseInt(e.target.value, 10) || 10, 2, 40);
});
["dragover", "dragenter"].forEach(ev => document.addEventListener(ev, e => { const dz = e.target.closest && e.target.closest("#drop"); if (dz) { e.preventDefault(); dz.classList.add("over"); } }));
document.addEventListener("dragleave", e => { const dz = e.target.closest && e.target.closest("#drop"); if (dz) dz.classList.remove("over"); });
document.addEventListener("drop", e => { const dz = e.target.closest && e.target.closest("#drop"); if (!dz) return; e.preventDefault(); dz.classList.remove("over"); if (e.dataTransfer.files.length) addFiles(S.decks[UI.deckId], e.dataTransfer.files); });

</script>
