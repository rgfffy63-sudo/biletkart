<script>
/* ============ экран: профиль ============ */
const PF = { auth: "login", test: null, testing: false, showKey: false, busy: false };
let AIDRAFT = null, INSTALL = null;
const KEY_HELP = {
  deepseek: ["platform.deepseek.com", "https://platform.deepseek.com/api_keys"],
  openai: ["platform.openai.com", "https://platform.openai.com/api-keys"],
  anthropic: ["console.anthropic.com", "https://console.anthropic.com/settings/keys"],
  gemini: ["aistudio.google.com", "https://aistudio.google.com/apikey"],
  openrouter: ["openrouter.ai", "https://openrouter.ai/keys"],
  groq: ["console.groq.com", "https://console.groq.com/keys"],
  mistral: ["console.mistral.ai", "https://console.mistral.ai/api-keys"],
};
window.addEventListener("beforeinstallprompt", e => { e.preventDefault(); INSTALL = e; if (UI.view === "profile") render(); });

function vProfile() {
  if (!AIDRAFT) AIDRAFT = Object.assign({}, AICFG);
  const u = ACC && ACC.user, pro = isPro();
  const P = PROVIDERS[AIDRAFT.provider] || PROVIDERS.custom, help = KEY_HELP[AIDRAFT.provider];
  const acc = STANDALONE ? `<p class="note" style="margin:0">Автономная версия. Аккаунтов и синхронизации здесь нет: колоды хранятся в этом браузере. Все функции, включая Pro, открыты. Для синхронизации между устройствами открой версию с сервером.</p>`
    : u ? `<div class="stack"><div><b>${esc(u.name || "Без имени")}</b><div class="muted">${esc(u.email)}</div></div>
      <div class="row">${pro ? `<span class="tag pro">PRO до ${new Date(u.pro_until * 1000).toLocaleDateString("ru-RU")}</span>` : `<span class="tag">Бесплатный тариф</span>`}<span class="grow"></span><button class="btn sm ghost" data-act="logout">Выйти</button></div></div>`
    : `<div class="stack"><div class="seg">${[["login", "Вход"], ["register", "Регистрация"]].map(([k, l]) => `<button data-act="auth-mode" data-v="${k}" aria-pressed="${PF.auth === k}">${l}</button>`).join("")}</div>
      <form id="authForm" class="stack" autocomplete="on">
        ${PF.auth === "register" ? `<div><label class="lbl" for="auName">Имя</label><input type="text" id="auName" autocomplete="name"></div>` : ""}
        <div><label class="lbl" for="auEmail">Email</label><input type="email" id="auEmail" autocomplete="email" required></div>
        <div><label class="lbl" for="auPw">Пароль</label><input type="password" id="auPw" autocomplete="${PF.auth === "register" ? "new-password" : "current-password"}" required minlength="6"></div>
        <div><button class="btn pri" type="submit" ${PF.busy ? "disabled" : ""}>${PF.busy ? `<span class="spin"></span>` : ""}${PF.auth === "register" ? "Создать аккаунт" : "Войти"}</button></div>
      </form><p class="note">Без аккаунта всё работает на этом устройстве. Аккаунт нужен для Pro и синхронизации.</p></div>`;
  const plan = STANDALONE ? `<p class="muted" style="margin:0">В автономной версии Pro открыт: симулятор экзамена, генератор билетов и аудио-прогон работают без подписки.</p>`
    : pro ? `<p class="muted" style="margin:0">Pro активен. Колоды синхронизируются между устройствами, симулятор экзамена и аудио-прогон открыты.</p>`
    : `<div class="upsell" style="padding:18px 20px"><b>Что даёт Pro</b><ul style="margin:8px 0 0"><li>Синхронизация между телефоном и компьютером</li><li>Симулятор экзамена и генератор билетов</li><li>Аудио-прогон карточек</li>${ACC && ACC.user && SERVER_OK.v !== false ? "" : ""}</ul></div>
      <p class="note">Оплата картой появится позже. Сейчас Pro включается промокодом.</p>
      <div class="keyrow"><input type="text" id="promo" placeholder="Промокод" aria-label="Промокод" ${u ? "" : "disabled"}><button class="btn pro" data-act="redeem" ${u ? "" : "disabled"}>Активировать</button></div>
      ${u ? "" : `<p class="note">Чтобы активировать промокод, войди в аккаунт.</p>`}`;
  const srvAi = pro && u && u.server_ai;
  const aiSec = `${srvAi ? `<label class="switch"><input type="checkbox" id="aiServer" ${AIDRAFT.useServer ? "checked" : ""}> Встроенный ИИ (без своего ключа)</label>` : ""}
    <div class="stack" ${srvAi && AIDRAFT.useServer ? "hidden" : ""}>
      <div><label class="lbl" for="aiProv">Провайдер</label><select id="aiProv">${Object.entries(PROVIDERS).map(([k, p]) => `<option value="${k}" ${k === AIDRAFT.provider ? "selected" : ""}>${esc(p.title)}</option>`).join("")}</select></div>
      ${AIDRAFT.provider === "custom" ? `<div><label class="lbl" for="aiBase">Адрес API</label><input type="url" id="aiBase" value="${esc(AIDRAFT.base_url)}" placeholder="https://.../v1"></div>` : ""}
      <div><label class="lbl" for="aiModel">Модель</label><input type="text" id="aiModel" value="${esc(AIDRAFT.model)}" placeholder="${esc(P.model || "название модели")}"><p class="note" style="margin-top:4px">Оставь пустым, чтобы взять модель по умолчанию. Названия моделей у провайдеров меняются: актуальные смотри в их документации.</p></div>
      <div><label class="lbl" for="aiKey">API-ключ</label><div class="keyrow"><input type="${PF.showKey ? "text" : "password"}" id="aiKey" value="${esc(AIDRAFT.key)}" placeholder="sk-..." autocomplete="off" spellcheck="false"><button class="ib" data-act="key-toggle" title="${PF.showKey ? "Скрыть" : "Показать"} ключ" aria-label="Показать или скрыть ключ">${PF.showKey ? "◡" : "◉"}</button></div>
        ${help ? `<p class="note" style="margin-top:4px">Ключ создаётся в личном кабинете: <a href="${help[1]}" target="_blank" rel="noopener">${help[0]}</a></p>` : ""}</div>
      ${P.vision ? `<p class="note">Эта модель понимает фото конспектов.</p>` : AIDRAFT.provider === "custom" || AIDRAFT.provider === "openrouter" ? "" : `<p class="note">Фото конспектов эта модель не распознаёт. Для фото выбери Claude, OpenAI или Gemini.</p>`}
    </div>
    <p class="note">Ключ хранится только на этом устройстве и не синхронизируется. Сервер передаёт запрос провайдеру и ключ не сохраняет.</p>
    ${PF.test ? `<div class="${PF.test.ok ? "okline" : "errline"}">${esc(PF.test.msg)}</div>` : ""}
    <div class="row"><button class="btn pri" data-act="ai-save">Сохранить</button><button class="btn" data-act="ai-test" ${PF.testing ? "disabled" : ""}>${PF.testing ? `<span class="spin"></span> Проверяю…` : "Проверить подключение"}</button></div>`;
  const rate = (S.meta.settings && S.meta.settings.rate) || 1;
  return `<header class="vh"><div><div class="eyebrow">профиль</div><h1>Профиль и настройки</h1></div>
      ${INSTALL ? `<button class="btn pri" data-act="install">Установить приложение</button>` : ""}</header>
    <div class="set-grid">
      <section class="panel stack" id="accSec"><h2 style="margin:0">Аккаунт</h2>${acc}</section>
      <section class="panel stack" id="aiSec"><div class="row"><h2 style="margin:0" class="grow">Нейросеть</h2>${aiOn() ? `<span class="tag ai">подключена</span>` : `<span class="tag">не подключена</span>`}</div>${aiSec}</section>
      <section class="panel stack" id="proSec"><div class="row"><h2 style="margin:0" class="grow">Подписка</h2><span class="tag ${pro ? "pro" : ""}">${pro ? "PRO" : "Free"}</span></div>${plan}</section>
      <section class="panel stack"><h2 style="margin:0">Голос</h2>
        ${CAP.tts ? `<div><div class="lbl">Скорость озвучки</div><div class="seg">${[0.8, 1, 1.2, 1.4].map(r => `<button data-act="voice-rate" data-v="${r}" aria-pressed="${rate === r}">${r}×</button>`).join("")}</div></div>
        <div><button class="btn" data-act="voice-test">${ICON.spk} Проверить озвучку</button></div>` : `<p class="note">Озвучка недоступна в этом браузере.</p>`}
        <p class="note">${CAP.dict ? "Ответы можно надиктовывать: кнопка с микрофоном рядом с полем ответа." : "Голосовой ввод в этом браузере недоступен. Он работает в Chrome и в приложении для Android."}</p></section>
      <section class="panel stack"><h2 style="margin:0">Данные</h2>
        <p class="note">Резервная копия — один файл со всеми колодами, материалами и статистикой. Пригодится, чтобы перенести данные без Pro.</p>
        <div class="row"><button class="btn" data-act="backup-export">Скачать копию</button><label class="btn" for="bkIn">Восстановить из файла</label><input type="file" id="bkIn" accept=".json,application/json" hidden></div>
        ${deckList().some(d => d.demo) ? `<div><button class="btn sm ghost danger" data-act="del-demo">Удалить колоды-примеры</button></div>` : ""}
      </section>
    </div>`;
}
function readAiForm() {
  if (!AIDRAFT) return;
  const g = id => { const el = $("#" + id); return el ? el.value.trim() : null; };
  const v = { provider: g("aiProv"), model: g("aiModel"), key: g("aiKey"), base_url: g("aiBase") };
  for (const k in v) if (v[k] != null) AIDRAFT[k] = v[k];
  const sv = $("#aiServer"); if (sv) AIDRAFT.useServer = sv.checked;
}
async function authSubmit() {
  const email = $("#auEmail").value.trim(), password = $("#auPw").value, name = $("#auName") ? $("#auName").value.trim() : "";
  PF.busy = true; render();
  try {
    const j = await api("POST", PF.auth === "register" ? "/api/auth/register" : "/api/auth/login", { email, password, name });
    setAccount({ token: j.token, user: j.user });
    toast(PF.auth === "register" ? "Аккаунт создан" : "С возвращением!");
    if (isPro()) syncPull();
  } catch (e) { toast(e.message || "Не получилось", "err"); }
  PF.busy = false; render();
}
Object.assign(ACT, {
  "goto-ai": () => { closeModal(); go("profile"); setTimeout(() => $("#aiSec")?.scrollIntoView({ block: "start", behavior: "smooth" }), 60); },
  "goto-pro": () => { closeModal(); go("profile"); setTimeout(() => $(ACC ? "#proSec" : "#accSec")?.scrollIntoView({ block: "start", behavior: "smooth" }), 60); },
  "auth-mode": el => { PF.auth = el.dataset.v; render(); },
  logout: async () => { try { await api("POST", "/api/auth/logout"); } catch (e) { } cloudReady = false; setAccount(null); toast("Ты вышел из аккаунта. Данные остались на устройстве"); render(); },
  redeem: async () => {
    const code = ($("#promo")?.value || "").trim(); if (!code) return;
    try { const j = await api("POST", "/api/billing/redeem", { code }); setAccount({ token: ACC.token, user: j.user }); toast("Pro активирован", "ai"); syncPull(); render(); }
    catch (e) { toast(e.message || "Не получилось", "err"); }
  },
  "key-toggle": () => { readAiForm(); PF.showKey = !PF.showKey; render(); },
  "ai-save": () => { readAiForm(); AICFG = Object.assign({}, AIDRAFT); LS.set("bk:ai", AICFG); updateSide(); PF.test = null; toast("Настройки нейросети сохранены"); render(); },
  "ai-test": async () => {
    readAiForm(); PF.testing = true; PF.test = null; render();
    const d = AIDRAFT, body = d.useServer && isPro() ? { use_server_ai: true } : { provider: d.provider, model: d.model, key: d.key, base_url: d.base_url };
    try { const t = STANDALONE ? await directAI(d, "Ответь одним словом: работает", [], 20) : (await api("POST", "/api/ai/test", body)).text; PF.test = { ok: true, msg: "Работает. Ответ модели: " + String(t).slice(0, 100) }; }
    catch (e) { PF.test = { ok: false, msg: aiErrText(e) }; }
    PF.testing = false; render();
  },
  "voice-rate": el => { S.meta.settings.rate = +el.dataset.v; touch("meta"); render(); },
  "voice-test": el => speak("Привет! Так будут звучать вопросы и ответы твоих карточек.", el),
  "backup-export": () => exportBackup(),
  "del-demo": () => { deckList().filter(d => d.demo).forEach(d => { deckMaterials(d).forEach(m => { delete S.materials[m.id]; removed.add("mat-" + m.id); dirty.delete("mat-" + m.id); }); delete S.decks[d.id]; removed.add("deck-" + d.id); dirty.delete("deck-" + d.id); }); S.meta.order = S.meta.order.filter(id => S.decks[id]); touch("meta"); render(); toast("Примеры удалены"); },
  install: async () => { if (!INSTALL) return; INSTALL.prompt(); try { await INSTALL.userChoice; } catch (e) { } INSTALL = null; render(); },
});
document.addEventListener("submit", e => { if (e.target.id === "authForm") { e.preventDefault(); authSubmit(); } });
document.addEventListener("change", e => {
  if (e.target.id === "aiProv") { readAiForm(); AIDRAFT.model = ""; PF.test = null; render(); }
  if (e.target.id === "aiServer") { readAiForm(); render(); }
  if (e.target.id === "bkIn" && e.target.files[0]) importBackup(e.target.files[0]);
});
</script>
