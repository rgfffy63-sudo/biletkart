<script>
/* ============ маршрутизация и общий рендер ============ */
function go(view, deckId) { const h = view === "deck" ? "deck-" + deckId : view; if (location.hash.slice(1) === h) route(); else location.hash = h; }
function route() {
  const h = location.hash.slice(1);
  if (h.startsWith("deck-") && S.decks[h.slice(5)]) { if (UI.deckId !== h.slice(5)) { UI.tab = "tickets"; UI.q = ""; } UI.view = "deck"; UI.deckId = h.slice(5); }
  else if (["review", "exam", "stats", "profile"].includes(h)) UI.view = h;
  else UI.view = "decks";
  render(); window.scrollTo(0, 0);
}
function render() {
  const main = $("#main");
  const nav = UI.view === "deck" ? "decks" : UI.view;
  $$("#nav button").forEach(b => b.setAttribute("aria-current", b.dataset.nav === nav ? "page" : "false"));
  const due = sum(deckList().map(deckDue)); const bd = $("#dueBadge"); bd.hidden = !due; bd.textContent = due;
  let html = "";
  try {
    if (UI.view === "deck") html = vDeck();
    else if (UI.view === "review") html = vReview();
    else if (UI.view === "exam") html = vExam();
    else if (UI.view === "stats") html = vStats();
    else if (UI.view === "profile") html = vProfile();
    else html = vDecks();
  } catch (e) { console.error(e); html = `<div class="empty">Что-то пошло не так при отрисовке: ${esc(e.message)}</div>`; }
  main.innerHTML = html;
  hydrate(main);
  if (UI.view === "review") afterReview();
  if (UI.view === "exam") afterExam();
}
function rerenderSoft() {
  const ae = document.activeElement; if (ae && ae.matches && ae.matches("textarea,input")) return;
  if (["decks", "deck", "stats", "profile"].includes(UI.view)) return render();
  if (UI.view === "review" && (!RV || (!RV.revealed && !RV.answer))) return render();
  if (UI.view === "exam" && (!EX || EX.state === "setup")) return render();
}
function ticketOf(deck, tid) { return deck.tickets.find(t => t.id === tid); }
function sortedTickets(deck) { return deck.tickets.slice().sort((a, b) => a.num - b.num); }

/* ============ экран: колоды ============ */
function vDecks() {
  const decks = deckList(); const due = sum(decks.map(deckDue)), nw = sum(decks.map(deckNew));
  return `<header class="vh"><div><div class="eyebrow">колоды</div><h1>Подготовка к экзамену по билетам</h1></div>
    <button class="btn" data-act="new-deck">${ICON.plus} Новая колода</button></header>
  <div class="today"><div><b>${due}</b> <span class="muted">${plural(due, "карточка ждёт", "карточки ждут", "карточек ждут")} повторения${nw ? ` · ${pl(nw, "новая карточка", "новые карточки", "новых карточек")}` : ""}</span></div>
    <div class="grow"></div><button class="btn pri" data-act="start-review" ${due + nw ? "" : "disabled"}>Начать повторение</button></div>
  <div class="deck-grid">${decks.map(deckCard).join("")}
    <button class="newdeck" data-act="new-deck"><span>+ Новая колода<br><small class="muted">список билетов, конспекты, PDF</small></span></button></div>`;
}
function deckCard(d) {
  const ts = sortedTickets(d), st = ts.map(t => ticketStat(d, t)), ok = st.filter(s => s.m != null && s.m >= 0.75).length;
  return `<article class="panel deck" data-act="open-deck" data-deck="${d.id}" tabindex="0">
    <div class="row"><h3 class="grow">${esc(d.name)}</h3>${d.demo ? `<span class="tag ex">пример</span>` : ""}</div>
    <div class="kv"><div><b>${ts.length}</b>билетов</div><div><b>${d.cards.length}</b>карточек</div><div><b class="due">${deckDue(d)}</b>к повтору</div></div>
    <div><div class="strip">${st.map((s, i) => `<i class="${lvClass(s.m)}" title="№${ts[i].num}: ${esc(lvLabel(s.m))}"></i>`).join("") || `<span class="muted mono" style="font-size:12px">билетов пока нет</span>`}</div>
    <div class="mlab">уверенно: ${ok} из ${ts.length} ${plural(ts.length, "билета", "билетов", "билетов")}</div></div>
  </article>`;
}

/* ============ экран: колода ============ */
let BATCH = null, MATBUSY = "";
function vDeck() {
  const d = S.decks[UI.deckId]; if (!d) return vDecks();
  const mats = deckMaterials(d);
  const noCards = d.tickets.filter(t => !d.cards.some(c => c.t === t.id)).length;
  let body = "";
  if (UI.tab === "tickets") {
    const q = UI.q.trim().toLowerCase();
    const ts = sortedTickets(d).filter(t => !q || t.title.toLowerCase().includes(q) || String(t.num) === q);
    body = `<div class="toolbar">
      <button class="btn" data-act="import-tickets">Импорт списка билетов</button>
      <button class="btn" data-act="add-ticket">${ICON.plus} Билет</button>
      ${BATCH && BATCH.deckId === d.id
        ? `<span class="btn ai" aria-live="polite"><span class="spin"></span> ИИ: ${BATCH.done} из ${BATCH.total}</span><button class="btn sm ghost" data-act="batch-stop">Остановить</button>`
        : `<button class="btn ai" data-act="gen-all" ${noCards ? "" : "disabled"}>${ICON.spark} Карточки для билетов без карточек${noCards ? ` (${noCards})` : ""}</button>`}
      <div class="grow"></div>
      <input type="text" id="tq" placeholder="Поиск по билетам" value="${esc(UI.q)}" style="max-width:220px" aria-label="Поиск по билетам">
    </div>
    ${!mats.length && d.tickets.length ? `<div class="today" style="border-left-color:var(--pink);background:linear-gradient(90deg,rgba(255,61,154,.07),transparent 70%)"><span>Загрузи конспекты или PDF во вкладке «Материалы»: в режиме «строго по материалам» ИИ отвечает только по ним.</span><div class="grow"></div><button class="btn sm" data-act="tab" data-tab="mats">Открыть материалы</button></div>` : ""}
    ${ts.length ? `<div class="tlist">${ts.map(t => ticketRow(d, t)).join("")}</div>`
      : `<div class="empty">${q ? "Ничего не нашлось" : "Добавь билеты: вставь список из методички или найди их в загруженном файле."}<div class="row" style="justify-content:center;margin-top:14px"><button class="btn pri" data-act="import-tickets">Импорт списка билетов</button></div></div>`}`;
  } else {
    body = `<label class="drop" id="drop" for="fileIn">
        <input type="file" id="fileIn" multiple accept=".pdf,.docx,.txt,.md,.markdown,image/png,image/jpeg,image/webp" hidden>
        <b>Перетащи файлы сюда или нажми, чтобы выбрать</b><br>
        <span class="mono" style="font-size:12px">PDF · DOCX · TXT · MD · фото конспекта (распознаёт ИИ)</span>
      </label>
      <div class="row" style="margin:12px 0 18px"><button class="btn" data-act="paste-mat">Вставить текст вручную</button>${MATBUSY ? `<span class="muted"><span class="spin"></span> ${esc(MATBUSY)}</span>` : ""}</div>
      ${mats.length ? `<div class="tlist">${mats.map(m => `<div class="mat"><span class="ftype">${esc(m.kind)}</span>
        <div class="grow"><b>${esc(m.name)}</b><div class="mlab">${pl(m.chunks.length, "фрагмент", "фрагмента", "фрагментов")} · ${Math.round(sum(m.chunks.map(c => c.length)) / 1000)} тыс. знаков</div></div>
        <div class="tacts"><button class="btn sm" data-act="view-mat" data-mid="${m.id}">Открыть</button><button class="ib" data-act="del-mat" data-mid="${m.id}" title="Удалить материал" aria-label="Удалить материал">${ICON.del}</button></div></div>`).join("")}</div>`
      : `<div class="empty">Материалов пока нет. Карточки без материалов ИИ создаст, только если отключить режим «строго по материалам» в настройках колоды.</div>`}`;
  }
  return `<header class="vh"><div><div class="eyebrow"><a href="#decks" style="color:inherit;text-decoration:none">колоды</a> / ${d.demo ? "пример" : "колода"}</div><h1>${esc(d.name)}</h1>
      <div class="row" style="margin-top:10px">${d.strict ? `<span class="tag ok">строго по материалам</span>` : `<span class="tag ex">ИИ может дополнять общими знаниями</span>`}<span class="mono muted" style="font-size:12px">${pl(d.tickets.length, "билет", "билета", "билетов")} · ${pl(d.cards.length, "карточка", "карточки", "карточек")} · ${deckDue(d)} к повтору</span></div></div>
    <div class="row"><button class="btn pri" data-act="review-deck" data-deck="${d.id}" ${d.cards.length ? "" : "disabled"}>Повторить</button><button class="btn" data-act="exam-deck" data-deck="${d.id}" ${d.tickets.length ? "" : "disabled"}>Экзамен</button><button class="ib" data-act="deck-settings" title="Настройки колоды" aria-label="Настройки колоды">${ICON.gear}</button></div></header>
  <div class="tabs" role="tablist"><button role="tab" data-act="tab" data-tab="tickets" aria-selected="${UI.tab === "tickets"}">Билеты</button><button role="tab" data-act="tab" data-tab="mats" aria-selected="${UI.tab === "mats"}">Материалы (${mats.length})</button></div>
  ${body}`;
}
function ticketRow(d, t) {
  const st = ticketStat(d, t), open = UI.open.has(t.id), busy = UI.busy.has(t.id);
  const cards = d.cards.filter(c => c.t === t.id);
  return `<div class="trow ${open ? "open" : ""}" id="tr-${t.id}">
    <div class="tnum">№${t.num}</div>
    <div class="ttitle"><button class="btn ghost" style="padding:0;white-space:normal;text-align:left;font-weight:500;color:var(--text)" data-act="toggle-ticket" data-tid="${t.id}" aria-expanded="${open}">${esc(t.title)}</button>
      <small>${pl(st.n, "карточка", "карточки", "карточек")}${st.due ? ` · ${st.due} к повтору` : ""}${t.exam != null ? ` · экзамен ${t.exam}%` : ""}</small></div>
    <div class="tm"><div class="mbar"><i style="width:${Math.round((st.m ?? 0) * 100)}%;background:${lvColor(st.m)}"></i></div><div class="mlab">${lvLabel(st.m)}${st.m != null ? " · " + Math.round(st.m * 100) + "%" : ""}</div></div>
    <div class="tacts">
      ${busy ? `<span class="btn sm ai"><span class="spin"></span> создаю…</span>` : `<button class="btn sm ai" data-act="gen-ticket" data-tid="${t.id}" title="ИИ создаст карточки по материалам">${ICON.spark} ИИ</button>`}
      <button class="ib" data-act="add-card" data-tid="${t.id}" title="Добавить карточку вручную" aria-label="Добавить карточку">${ICON.plus}</button>
      <button class="ib" data-act="edit-ticket" data-tid="${t.id}" title="Изменить билет" aria-label="Изменить билет">${ICON.edit}</button>
    </div></div>
  ${open ? `<div class="tcards">${cards.length ? cards.map(c => cardItem(d, c)).join("") : `<div class="muted" style="padding:8px 0">Карточек нет. Нажми «ИИ», чтобы создать их по материалам, или «+», чтобы написать самому.</div>`}${t.note ? `<div class="warn">${esc(t.note)}</div>` : ""}</div>` : ""}`;
}
function cardItem(d, c) {
  const nextIn = c.hist && c.hist.length ? (c.due <= Date.now() ? "пора повторить" : "через " + fmtIvl((c.due - Date.now()) / DAY)) : "новая";
  return `<div class="citem"><div class="cq rich">${renderRich(c.q)}</div>
    <details><summary>Ответ</summary><div class="rich">${renderRich(c.a)}</div></details>
    <div class="cfoot">${c.ai ? `<span class="tag ai">ИИ</span>` : `<span class="tag">вручную</span>`}
      ${(c.src || []).map(s => `<button class="src" data-act="show-src" data-cid="${esc(s)}" data-card="${c.id}">${esc(srcLabel(s))}</button>`).join("")}
      ${(c.check || []).slice(0, 4).map(x => `<span class="chk" title="Сверь с источником">проверь: ${esc(x)}</span>`).join("")}
      <span class="grow"></span><span>${nextIn}</span>
      <button class="ib" data-act="edit-card" data-cid="${c.id}" title="Редактировать" aria-label="Редактировать карточку">${ICON.edit}</button>
      <button class="ib" data-act="del-card" data-cid="${c.id}" title="Удалить" aria-label="Удалить карточку">${ICON.del}</button></div></div>`;
}

/* --- генерация карточек --- */
function cardPrompt(d, t, frags, existing) {
  return `Ты — методист. Делаешь учебные карточки «вопрос — ответ» для подготовки к устному экзамену по билетам.
Предмет: ${d.name}
Билет №${t.num}: «${t.title}»
${d.strict ? `РЕЖИМ «СТРОГО ПО МАТЕРИАЛАМ». Используй только факты из фрагментов ниже. Ничего не добавляй из общих знаний. Если во фрагментах нет материала для ответа на этот билет, ответь одной строкой: @@NOTFOUND <коротко, чего не хватает>` : `Опирайся в первую очередь на фрагменты. Если чего-то во фрагментах нет, можешь дополнить общими знаниями, но у такой карточки строку SRC оставь пустой.`}

Фрагменты материалов студента:
${frags.length ? fragBlock(frags) : "(материалы не загружены)"}
${existing.length ? `\nТакие карточки уже есть, не повторяй их:\n- ${existing.join("\n- ")}\n` : ""}
Сделай от 3 до 6 карточек: от главного определения к деталям, формулам, примерам. Вопрос — одна чёткая фраза, как спросит преподаватель. Ответ — до 90 слов, по делу, со структурой.
${FORMAT_RULES}

Формат ответа строго такой, без вступления и без пояснений после:
@@CARD
Q: вопрос
A:
ответ (можно несколько строк)
SRC: номера фрагментов, на которых основан ответ, например F1, F3
QUOTE: дословная цитата из фрагмента до 15 слов, подтверждающая ответ
CHECK: термины, числа, даты или номера статей, которые стоит сверить с источником, через ;
@@END`;
}
async function genTicket(deckId, tid, signal) {
  const d = S.decks[deckId], t = d && ticketOf(d, tid); if (!t) return 0;
  const frags = retrieve(d, t.title, 6);
  if (d.strict && !frags.length) { t.note = deckMaterials(d).length ? "В материалах не нашлось фрагментов по этому билету. Проверь формулировку или загрузи нужный конспект." : "Нет материалов: загрузи конспекты во вкладке «Материалы» или выключи строгий режим."; touch("deck-" + d.id); return 0; }
  UI.busy.add(tid); if (UI.view === "deck") render();
  try {
    const existing = d.cards.filter(c => c.t === tid).map(c => c.q.slice(0, 120));
    const text = await ai(cardPrompt(d, t, frags, existing), { signal, cache: false });
    if (/@@NOTFOUND/.test(text) && !/@@CARD/.test(text)) { t.note = "ИИ: в материалах нет ответа на этот билет. " + text.split("@@NOTFOUND")[1].trim().slice(0, 200); touch("deck-" + d.id); return 0; }
    const blocks = text.split("@@CARD").slice(1).map(b => b.split("@@END")[0]);
    let n = 0;
    for (const b of blocks) {
      const p = parseTagged(b, ["Q", "A", "SRC", "QUOTE", "CHECK"]); if (!p.Q || !p.A) continue;
      const src = (p.SRC || "").match(/F\d+/gi) || [];
      const ids = Array.from(new Set(src.map(f => frags[+f.slice(1) - 1]).filter(Boolean).map(f => f.id)));
      d.cards.push({ id: "c" + uid(), t: tid, q: p.Q, a: p.A, src: ids, quote: (p.QUOTE || "").replace(/^["«]|["»]$/g, ""), check: (p.CHECK || "").split(/[;\n]/).map(s => s.replace(/^[-–\s]+/, "").trim()).filter(s => s && !/^нет\.?$/i.test(s)).slice(0, 5), ai: true, hist: [], reps: 0, ivl: 0, ease: 2.5, due: 0, createdAt: Date.now() });
      n++;
    }
    t.note = n ? "" : "ИИ не вернул карточек в нужном формате, попробуй ещё раз.";
    if (n) UI.open.add(tid);
    touch("deck-" + d.id);
    return n;
  } finally { UI.busy.delete(tid); if (UI.view === "deck") render(); }
}
async function genAll(d) {
  const ts = sortedTickets(d).filter(t => !d.cards.some(c => c.t === t.id));
  if (!ts.length) return;
  BATCH = { deckId: d.id, total: ts.length, done: 0, ctl: new AbortController(), made: 0 };
  render();
  for (const t of ts) {
    if (BATCH.ctl.signal.aborted) break;
    try { BATCH.made += await genTicket(d.id, t.id, BATCH.ctl.signal); }
    catch (e) { if (e && e.code === "cancelled") break; toast(aiErrText(e), "err"); if (e && ["rate_limited", "no_ai", "not_granted"].includes(e.code)) break; }
    BATCH.done++; if (UI.view === "deck") render();
  }
  const made = BATCH.made; BATCH = null; render();
  toast(`Готово: ${pl(made, "новая карточка", "новые карточки", "новых карточек")}`, "ai");
}

/* --- материалы --- */
function chunkText(text) {
  text = String(text || "").replace(/\r/g, "").replace(/ /g, " ").replace(/[ \t]+\n/g, "\n");
  const paras = text.split(/\n\s*\n/).map(p => p.replace(/\s*\n\s*/g, " ").trim()).filter(p => p.length > 1);
  const out = []; let buf = "";
  const flush = () => { if (buf.trim()) out.push(buf.trim()); buf = ""; };
  for (const p of paras) {
    if (p.length > 1100) {
      flush(); const sents = p.match(/[^.!?…]+[.!?…]+["»)\]]*\s*|[^.!?…]+$/g) || [p]; let b = "";
      for (const s of sents) { if ((b + s).length > 800 && b) { out.push(b.trim()); b = ""; } b += s; }
      if (b.trim()) out.push(b.trim());
    } else if (buf && (buf.length + p.length) > 800) { flush(); buf = p; }
    else buf = buf ? buf + "\n" + p : p;
  }
  flush(); return out;
}
function addMaterialText(d, name, kind, text) {
  const chunks = chunkText(text);
  if (!chunks.length) { toast(`В «${name}» не нашлось текста`, "err"); return 0; }
  const parts = []; let cur = [], size = 0;
  for (const c of chunks) { if (size + c.length > 140000 && cur.length) { parts.push(cur); cur = []; size = 0; } cur.push(c); size += c.length; }
  if (cur.length) parts.push(cur);
  parts.forEach((p, i) => { const id = "m" + uid(); S.materials[id] = { id, deckId: d.id, name: parts.length > 1 ? `${name} (ч. ${i + 1})` : name, kind, addedAt: Date.now() + i, chunks: p }; touch("mat-" + id); });
  return chunks.length;
}
async function pdfToText(file) {
  await loadLib("pdfw"); await loadLib("pdf");
  const lib = window.pdfjsLib; lib.GlobalWorkerOptions.workerSrc = LIBSRC.pdfw;
  const pdf = await lib.getDocument({ data: new Uint8Array(await file.arrayBuffer()), isEvalSupported: false }).promise;
  const pages = [];
  for (let p = 1; p <= pdf.numPages; p++) {
    MATBUSY = `Читаю ${file.name}: страница ${p} из ${pdf.numPages}`; if (UI.view === "deck" && p % 5 === 1) render();
    const tc = await (await pdf.getPage(p)).getTextContent();
    let line = "", lines = [], eol = tc.items.some(i => i.hasEOL);
    for (const it of tc.items) { line += it.str; if (it.hasEOL) { lines.push(line); line = ""; } else if (!eol) line += " "; }
    if (line) lines.push(line);
    pages.push(lines.join("\n"));
  }
  return pages.join("\n\n");
}
async function addFiles(d, files) {
  for (const f of Array.from(files)) {
    const ext = (f.name.split(".").pop() || "").toLowerCase();
    MATBUSY = `Читаю ${f.name}…`; if (UI.view === "deck") render();
    try {
      let text = "", kind = ext.toUpperCase();
      if (ext === "pdf") text = await pdfToText(f);
      else if (ext === "docx") { await loadLib("mammoth"); text = (await mammoth.extractRawText({ arrayBuffer: await f.arrayBuffer() })).value; }
      else if (["txt", "md", "markdown"].includes(ext)) text = await f.text();
      else if (/^image\//.test(f.type)) {
        if (!aiOn()) { openAiSetup(); continue; }
        if (!visionOn()) { toast("Выбранная модель не понимает фото. Переключись на Claude, OpenAI или Gemini в профиле", "err"); continue; }
        kind = "ФОТО"; MATBUSY = `ИИ распознаёт фото ${f.name}…`; if (UI.view === "deck") render();
        text = await ai(`На изображении — страница студенческого конспекта, учебника или слайда. Перепиши весь текст максимально точно, сохраняя порядок. Абзацы разделяй пустой строкой. Формулы записывай в LaTeX внутри \\( ... \\) или \\[ ... \\]. Нечитаемые места помечай [неразборчиво]. Выведи только текст, без комментариев.`, { images: [f] });
      } else { toast(`Формат .${ext} пока не поддерживается`, "err"); continue; }
      const n = addMaterialText(d, f.name, kind, text);
      if (n) toast(`${f.name}: ${pl(n, "фрагмент", "фрагмента", "фрагментов")}`);
    } catch (e) { toast(e && e.code ? aiErrText(e) : `Не удалось прочитать ${f.name}: ${e && e.message ? e.message : "ошибка"}`, "err"); }
  }
  MATBUSY = ""; if (UI.view === "deck") render();
}

/* ============ экран: повторение ============ */
let RV = null, RVSET = { decks: null, mode: "due", method: "self" };
function buildQueue(deckIds, mode) {
  const now = Date.now(), due = [], nw = [], limit = S.meta.settings.newPerSession || 20;
  for (const id of deckIds) {
    const d = S.decks[id]; if (!d) continue;
    const tm = {}; d.tickets.forEach(t => tm[t.id] = ticketStat(d, t).m);
    for (const c of d.cards) {
      const m = tm[c.t] ?? null, isNew = !(c.hist && c.hist.length);
      if (mode === "all") due.push({ d: id, c: c.id, p: Math.random() });
      else if (mode === "weak") { if (m != null && m < 0.6) due.push({ d: id, c: c.id, p: (1 - m) + Math.random() * 0.2 }); }
      else if (isNew) nw.push({ d: id, c: c.id, p: 1 + (1 - (m ?? 0)) + Math.random() * 0.1 });
      else if (c.due <= now) due.push({ d: id, c: c.id, p: 2 + (now - c.due) / DAY * 0.1 + (1 - (m ?? 0.5)) * 2 });
    }
  }
  nw.sort((a, b) => b.p - a.p);
  return due.concat(nw.slice(0, limit)).sort((a, b) => b.p - a.p);
}
function rvCur() { if (!RV) return null; const it = RV.queue[RV.i]; if (!it) return null; const d = S.decks[it.d]; const c = d && d.cards.find(x => x.id === it.c); if (!c) return null; return { d, c, t: ticketOf(d, c.t) || { num: "?", title: "" } }; }
function startReview(deckIds, mode, method) {
  const q = buildQueue(deckIds, mode);
  if (!q.length) { toast(mode === "weak" ? "Слабых билетов нет: сначала повтори карточки хотя бы раз" : "Сейчас нечего повторять", ""); return; }
  RV = { deckIds, mode, method, queue: q, i: 0, revealed: false, answer: "", check: null, stats: [0, 0, 0, 0], touched: new Set() };
  go("review");
}
function vReview() {
  if (!RV) return vReviewSetup();
  while (RV.i < RV.queue.length && !rvCur()) RV.i++;
  if (RV.i >= RV.queue.length) return vReviewDone();
  const { d, c, t } = rvCur();
  const pct = Math.round(RV.i / RV.queue.length * 100);
  const self = RV.method === "self";
  let lower = "";
  if (!RV.revealed) {
    lower = self ? `<div style="margin-top:20px"><label class="lbl" for="rvAns">Ответь своими словами</label>
      <div class="answer-box"><textarea id="rvAns" placeholder="Расскажи, как отвечал бы преподавателю. Ctrl+Enter — проверить">${esc(RV.answer)}</textarea>${micBtn("#rvAns")}</div><div class="partial"></div>
      <div class="row" style="margin-top:10px"><button class="btn ai solid" data-act="rv-check">${ICON.spark} Проверить с ИИ</button><button class="btn ghost" data-act="rv-reveal">Показать ответ</button></div></div>`
      : `<div class="row" style="margin-top:22px"><button class="btn pri" data-act="rv-reveal">Показать ответ <span class="mono" style="opacity:.6;font-size:11px">[пробел]</span></button></div>`;
  } else {
    const sug = RV.check && RV.check.res ? RV.check.res.grade : null;
    lower = `${RV.answer ? `<div style="margin-top:18px"><div class="lbl">Твой ответ</div><div class="muted" style="white-space:pre-wrap">${esc(RV.answer)}</div></div>` : ""}
      ${checkPanel()}
      <div class="atext"><div class="lbl">Ответ по материалам</div><div class="rich">${renderRich(c.a)}</div>
        <div class="cfoot" style="margin-top:12px">${(c.src || []).map(s => `<button class="src" data-act="show-src" data-cid="${esc(s)}" data-card="${c.id}">${esc(srcLabel(s))}</button>`).join("")}${(c.check || []).slice(0, 4).map(x => `<span class="chk">проверь: ${esc(x)}</span>`).join("")}</div></div>
      <div class="grades">${["Не вспомнил", "Трудно", "Хорошо", "Легко"].map((l, g) => `<button class="g${g} ${sug === g ? "sug" : ""}" data-act="rv-grade" data-g="${g}">${l}<small>${g === 0 ? "через 10 мин" : "через " + fmtIvl(schedule(c, g, true))}</small><kbd>${g + 1}</kbd></button>`).join("")}</div>`;
  }
  return `<div class="rv-wrap">
    <div class="rv-head"><span>${RV.i + 1} / ${RV.queue.length}</span><div class="prog"><i style="width:${pct}%"></i></div>
      <span>${RV.mode === "weak" ? "слабые билеты" : RV.mode === "all" ? "все подряд" : "по расписанию"}</span><button class="btn sm ghost" data-act="rv-exit">Завершить</button></div>
    <section class="panel qcard">
      <div class="tl"><span>${esc(d.name)}</span><span style="color:var(--dim)">/</span><span>Билет №${esc(t.num)}</span><span class="grow"></span>
        ${CAP.tts ? `<button class="ib" data-act="speak" data-what="${RV.revealed ? "qa" : "q"}" title="Озвучить" aria-label="Озвучить">${ICON.spk}</button>` : ""}
        ${RV.revealed ? `<button class="btn sm ai" data-act="explain">Объясни проще</button>` : ""}</div>
      <div class="muted" style="font-size:13px;margin:-6px 0 12px">${esc(t.title)}</div>
      <div class="qtext rich">${renderRich(c.q)}</div>
      ${lower}
    </section></div>`;
}
function checkPanel() {
  const ck = RV.check; if (!ck) return "";
  if (ck.state === "loading") return `<div class="aires"><span class="spin"></span> ИИ сверяет твой ответ с материалом…</div>`;
  if (ck.state === "error") return `<div class="aires"><span class="warn">${esc(ck.err)}</span></div>`;
  const r = ck.res, col = r.score >= 85 ? "var(--good)" : r.score >= 60 ? "var(--cyan)" : r.score >= 35 ? "var(--amber)" : "var(--bad)";
  const sec = (h, v, c) => v && !/^[-–\s]*нет\.?$/i.test(v.trim()) ? `<div><h4 style="color:${c}">${h}</h4><div class="rich">${renderRich(v)}</div></div>` : "";
  return `<div class="aires"><div class="score"><b style="color:${col}">${r.score}</b><div><div class="eyebrow m" style="margin:0">оценка ИИ · из 100</div><div>${esc(r.verdict)}</div></div></div>
    <div class="res-grid">${sec("Верно", r.ok, "var(--good)")}${sec("Не хватило", r.miss, "var(--amber)")}${sec("Ошибки", r.err, "var(--bad)")}</div>
    ${r.tip ? `<div style="margin-top:12px"><h4 class="mono" style="margin:0 0 4px;font-size:11px;letter-spacing:.1em;color:var(--pink)">КАК ЗАПОМНИТЬ</h4><div class="rich">${renderRich(r.tip)}</div></div>` : ""}</div>`;
}
async function rvCheck() {
  if (!aiOn()) { openAiSetup(); return; }
  const cur = rvCur(); if (!cur) return;
  const ans = ($("#rvAns")?.value || "").trim(); RV.answer = ans;
  if (!ans) { toast("Сначала напиши или надиктуй ответ"); return; }
  const { d, c, t } = cur; const myI = RV.i;
  RV.revealed = true; RV.check = { state: "loading" }; render();
  const frags = (c.src || []).map(chunkById).filter(Boolean).map(x => ({ mat: x.mat, n: x.n, text: x.text }));
  const prompt = `Ты — доброжелательный, но строгий преподаватель. Сравни ответ студента с эталоном.
Предмет: ${d.name}. Билет №${t.num}: «${t.title}».
Вопрос: ${c.q}
Эталонный ответ:
${c.a}
${frags.length ? "\nФрагменты материала:\n" + fragBlock(frags) + "\n" : ""}
Ответ студента (своими словами, мог быть надиктован голосом, поэтому не придирайся к опечаткам и пунктуации):
"""${ans.slice(0, 6000)}"""

Оценивай смысл, а не дословность. ${d.strict ? "Опирайся только на эталон и фрагменты, не требуй того, чего там нет." : ""}
Формулы пиши в LaTeX \\( ... \\).
Формат ответа строго такой:
SCORE: число от 0 до 100
VERDICT: одна короткая фраза
OK:
- что студент сказал верно
MISS:
- что важного не упомянул
ERR:
- фактические ошибки (если их нет, напиши "- нет")
TIP: одна-две фразы, как запомнить недостающее`;
  try {
    const text = await ai(prompt, { cache: false });
    const p = parseTagged(text, ["SCORE", "VERDICT", "OK", "MISS", "ERR", "TIP"]);
    const score = clamp(parseInt(p.SCORE, 10) || 0, 0, 100);
    if (!RV || RV.i !== myI) return;
    RV.check = { state: "ok", res: { score, verdict: p.VERDICT || "", ok: p.OK || "", miss: p.MISS || "", err: p.ERR || "", tip: p.TIP || "", grade: score < 40 ? 0 : score < 65 ? 1 : score < 90 ? 2 : 3 } };
  } catch (e) { if (!RV || RV.i !== myI) return; RV.check = { state: "error", err: aiErrText(e) }; }
  render();
}
function rvGrade(g) {
  const cur = rvCur(); if (!cur || !RV.revealed) return;
  const { d, c } = cur; const wasNew = !(c.hist && c.hist.length);
  schedule(c, g);
  const k = dayKey(); S.meta.days[k] = (S.meta.days[k] || 0) + 1;
  if (wasNew) S.meta.newToday[k] = (S.meta.newToday[k] || 0) + 1;
  RV.stats[g]++; RV.touched.add(d.id + "|" + c.t);
  if (g === 0) RV.queue.splice(Math.min(RV.queue.length, RV.i + 4), 0, { d: d.id, c: c.id, p: 0 });
  touch("deck-" + d.id); touch("meta");
  RV.i++; RV.revealed = false; RV.answer = ""; RV.check = null;
  render();
}
function vReviewSetup() {
  const decks = deckList(); if (!RVSET.decks) RVSET.decks = decks.map(d => d.id);
  const sel = RVSET.decks.filter(id => S.decks[id]);
  const q = buildQueue(sel, RVSET.mode);
  return `<header class="vh"><div><div class="eyebrow">повторение</div><h1>Интервальное повторение</h1></div></header>
  <div class="setup-grid">
    <section class="panel stack"><h2>Что повторяем</h2>
      <div><div class="lbl">Колоды</div><div class="chips">${decks.map(d => `<button class="chip" data-act="rv-deck" data-deck="${d.id}" aria-pressed="${sel.includes(d.id)}">${esc(d.name)} <span class="mono" style="color:var(--pink)">${deckDue(d) || ""}</span></button>`).join("") || `<span class="muted">Колод пока нет</span>`}</div></div>
      <div><div class="lbl">Режим</div><div class="seg">${[["due", "По расписанию"], ["weak", "Слабые билеты"], ["all", "Все подряд"]].map(([k, l]) => `<button data-act="rv-mode" data-mode="${k}" aria-pressed="${RVSET.mode === k}">${l}</button>`).join("")}</div></div>
      <p class="muted" style="margin:0;font-size:13.5px">${RVSET.mode === "due" ? "Карточки, которым пора, плюс новые. Слабые билеты идут первыми." : RVSET.mode === "weak" ? "Только билеты, где уверенность ниже 60%." : "Все карточки выбранных колод в случайном порядке."}</p>
    </section>
    <section class="panel stack"><h2>Как отвечаем</h2>
      <div class="seg">${[["self", "Своими словами"], ["flip", "Показать ответ"]].map(([k, l]) => `<button data-act="rv-method" data-method="${k}" aria-pressed="${RVSET.method === k}">${l}</button>`).join("")}</div>
      <p class="muted" style="margin:0;font-size:13.5px">${RVSET.method === "self" ? `Пишешь или ${CAP.dict ? "надиктовываешь" : "печатаешь"} ответ, ${aiOn() ? "ИИ сравнивает его с материалом и показывает, чего не хватило." : "потом сверяешь с эталоном."}` : "Классический режим Anki: вспомнил про себя, открыл ответ, оценил."}</p>
      <div class="grow"></div>
      <div class="row"><button class="btn pri" data-act="rv-start" ${q.length ? "" : "disabled"}>Начать · ${pl(q.length, "карточка", "карточки", "карточек")}</button>
      ${CAP.tts ? `<button class="btn" data-act="audio-run" ${q.length ? "" : "disabled"}>${ICON.spk} Аудио-прогон ${isPro() ? "" : `<span class="lock">PRO</span>`}</button>` : ""}</div>
      ${CAP.tts ? `<p class="muted" style="margin:0;font-size:12.5px">Аудио-прогон читает вопрос, даёт паузу подумать и читает ответ. Удобно в дороге.</p>` : ""}
    </section></div>`;
}
function vReviewDone() {
  const st = RV.stats, n = sum(st);
  const ts = Array.from(RV.touched).map(k => { const [di, ti] = k.split("|"); const d = S.decks[di]; const t = d && ticketOf(d, ti); return t ? { d, t, s: ticketStat(d, t) } : null; }).filter(Boolean).sort((a, b) => (a.s.m ?? 0) - (b.s.m ?? 0));
  return `<div class="rv-wrap"><section class="panel qcard"><div class="eyebrow">сессия завершена</div><h1 style="margin-bottom:14px">${pl(n, "ответ", "ответа", "ответов")}</h1>
    <div class="kv" style="margin-bottom:18px"><div><b style="color:var(--bad)">${st[0]}</b>не вспомнил</div><div><b style="color:var(--amber)">${st[1]}</b>трудно</div><div><b style="color:var(--cyan)">${st[2]}</b>хорошо</div><div><b style="color:var(--good)">${st[3]}</b>легко</div></div>
    ${ts.length ? `<div class="lbl">Билеты в этой сессии</div><div class="tlist" style="margin-bottom:18px">${ts.map(({ d, t, s }) => `<div class="trow" style="grid-template-columns:58px minmax(0,1fr) 150px"><div class="tnum">№${t.num}</div><div class="ttitle">${esc(t.title)}<small>${esc(d.name)}</small></div><div class="tm"><div class="mbar"><i style="width:${Math.round((s.m ?? 0) * 100)}%;background:${lvColor(s.m)}"></i></div><div class="mlab">${lvLabel(s.m)}</div></div></div>`).join("")}</div>` : ""}
    <div class="row"><button class="btn pri" data-act="rv-weak-again">Повторить слабые билеты</button><button class="btn" data-act="rv-exit">Готово</button></div></section></div>`;
}
function afterReview() {
  const ta = $("#rvAns"); if (ta) { ta.addEventListener("input", () => { if (RV) RV.answer = ta.value; }); if (RV && !RV.revealed) ta.focus({ preventScroll: true }); }
}
async function explainCard() {
  if (!aiOn()) { openAiSetup(); return; }
  const cur = rvCur(); if (!cur) return;
  const { d, c, t } = cur;
  const ctl = new AbortController();
  const m = openModal(`<div class="modal-h"><div><div class="eyebrow m">объясни проще</div><h2>${esc(t.title)}</h2></div><button class="ib" data-act="close" aria-label="Закрыть">✕</button></div>
    <div id="exBody" class="rich" style="white-space:pre-wrap"><span class="muted"><span class="spin"></span> Думаю, как объяснить…</span></div>
    <div class="modal-f"><button class="btn" data-act="close">Закрыть</button></div>`, { onClose: () => ctl.abort() });
  const body = $("#exBody", m);
  const prompt = `Объясни простыми словами, как другу-студенту, ответ на экзаменационный вопрос.
Предмет: ${d.name}. Билет №${t.num}: «${t.title}».
Вопрос: ${c.q}
Эталонный ответ:
${c.a}
${d.strict ? "Не добавляй новых фактов, которых нет в эталоне; аналогии и бытовые примеры можно." : ""}
Структура (заголовки жирным): **Суть** — два предложения; **Аналогия**; **Как запомнить** — мнемоника или приём; **Типичная ошибка на экзамене**.
До 170 слов. Формулы — LaTeX \\( ... \\).`;
  try {
    const text = await ai(prompt, { signal: ctl.signal, onText: ({ text }) => { body.textContent = text; } });
    body.style.whiteSpace = "normal"; body.innerHTML = renderRich(text); hydrate(body);
  } catch (e) { if (e && e.code === "cancelled") return; body.style.whiteSpace = "normal"; body.innerHTML = `<span class="warn">${esc(aiErrText(e))}</span>`; }
}
let AUDIO = null;
async function audioRun() {
  const sel = RVSET.decks.filter(id => S.decks[id]); const q = buildQueue(sel, RVSET.mode).slice(0, 40);
  if (!q.length || !CAP.tts) return;
  if (!isPro()) { needPro("Аудио-прогон"); return; }
  AUDIO = { stop: false };
  const m = openModal(`<div class="modal-h"><div><div class="eyebrow">аудио-прогон</div><h2 id="auHead">Готовлюсь…</h2></div></div>
    <div id="auQ" class="rich qtext" style="font-size:17px"></div><div id="auA" class="rich atext" hidden></div>
    <div class="modal-f"><span class="mono muted grow" id="auPos"></span><button class="btn pri" data-act="close">${ICON.stop} Остановить</button></div>`, { onClose: () => { AUDIO && (AUDIO.stop = true); try { CAP.tts.stop(); } catch (e) { } } });
  const wait = ms => new Promise(r => { const t0 = Date.now(); (function w() { if (!AUDIO || AUDIO.stop || Date.now() - t0 >= ms) return r(); setTimeout(w, 120); })(); });
  for (let i = 0; i < q.length; i++) {
    if (!AUDIO || AUDIO.stop) break;
    const d = S.decks[q[i].d], c = d && d.cards.find(x => x.id === q[i].c); if (!c) continue;
    const t = ticketOf(d, c.t) || { num: "?", title: "" };
    $("#auHead", m).textContent = `Билет №${t.num}. ${t.title}`; $("#auPos", m).textContent = `${i + 1} / ${q.length}`;
    const qa = $("#auQ", m), aa = $("#auA", m); qa.innerHTML = renderRich(c.q); aa.hidden = true; aa.innerHTML = renderRich(c.a); hydrate(m);
    try { await CAP.tts.speak(`Билет ${t.num}. ${plain(c.q)}`); } catch (e) { break; }
    await wait(5000); if (!AUDIO || AUDIO.stop) break;
    aa.hidden = false;
    try { await CAP.tts.speak("Ответ. " + plain(c.a)); } catch (e) { break; }
    await wait(1500);
  }
  if (AUDIO && !AUDIO.stop) { $("#auHead", m).textContent = "Прогон закончен"; }
  AUDIO = null;
}
</script>
