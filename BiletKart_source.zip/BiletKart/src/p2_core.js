<script>
"use strict";
/* ============ утилиты ============ */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);
const DAY = 864e5;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const sum = a => a.reduce((x, y) => x + y, 0);
const dayKey = (t = Date.now()) => { const d = new Date(t); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); };
function plural(n, a, b, c) { n = Math.abs(n) % 100; const n1 = n % 10; if (n > 10 && n < 20) return c; if (n1 > 1 && n1 < 5) return b; if (n1 === 1) return a; return c; }
const pl = (n, a, b, c) => n + " " + plural(n, a, b, c);
function fmtIvl(days) { if (days < 1) return "<1 дн"; if (days < 30) return Math.round(days) + " дн"; if (days < 365) return Math.round(days / 30) + " мес"; return (days / 365).toFixed(1) + " г"; }

const LIBS = {
  marked: ["vendor/marked.umd.js", "https://cdnjs.cloudflare.com/ajax/libs/marked/12.0.2/marked.min.js"],
  purify: ["vendor/purify.min.js", "https://cdnjs.cloudflare.com/ajax/libs/dompurify/3.1.6/purify.min.js"],
  hljs: ["vendor/highlight.min.js", "https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js"],
  mathjax: ["vendor/mathjax/tex-svg.js", "https://cdn.jsdelivr.net/npm/mathjax@3.2.2/es5/tex-svg.js"],
  mermaid: ["vendor/mermaid.min.js", "https://cdn.jsdelivr.net/npm/mermaid@10.9.1/dist/mermaid.min.js"],
  mathjs: ["vendor/math.min.js", "https://cdnjs.cloudflare.com/ajax/libs/mathjs/12.4.2/math.min.js"],
  pdfw: ["vendor/pdf.worker.min.js", "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js"],
  pdf: ["vendor/pdf.min.js", "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"],
  mammoth: ["vendor/mammoth.browser.min.js", "https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.6.0/mammoth.browser.min.js"],
};
const _libs = {}, LIBSRC = {};
function loadOne(src) {
  return new Promise((res, rej) => { const s = document.createElement("script"); s.src = src; s.async = true; s.onload = () => res(src); s.onerror = () => { s.remove(); rej(new Error(src)); }; document.head.appendChild(s); });
}
function loadLib(name) {
  if (_libs[name]) return _libs[name];
  const [local, cdn] = LIBS[name];
  return (_libs[name] = loadOne(local).catch(() => loadOne(cdn)).then(src => (LIBSRC[name] = src))
    .catch(() => { delete _libs[name]; throw new Error("Не загрузилась библиотека: проверь интернет"); }));
}

/* ============ состояние ============ */
let S = { decks: {}, materials: {}, meta: defaultMeta() };
const UI = { view: "decks", deckId: null, tab: "tickets", open: new Set(), busy: new Set(), q: "" };
const CAP = { tts: null, dict: null };
let cloudReady = false;
const dirty = new Set(), removed = new Set();
const LS = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { v == null ? localStorage.removeItem(k) : localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } },
};
const API = ((window.BK_CONFIG && BK_CONFIG.apiBase) || "").replace(/\/$/, "");
/* Автономный режим: сайт открыт как файл (или так задано в config) и сервера нет. Нейросеть зовём напрямую, Pro открыт локально. */
const STANDALONE = location.protocol === "file:" || !!(window.BK_CONFIG && BK_CONFIG.standalone);
let ACC = LS.get("bk:auth", null);           // {token, user}
let AICFG = Object.assign({ provider: "deepseek", model: "", key: "", base_url: "", useServer: false }, LS.get("bk:ai", {}));
let PROVIDERS = {
  deepseek: { title: "DeepSeek", model: "deepseek-chat", vision: false },
  openai: { title: "OpenAI", model: "gpt-4o-mini", vision: true },
  anthropic: { title: "Claude (Anthropic)", model: "claude-haiku-5-5", vision: true },
  gemini: { title: "Google Gemini", model: "gemini-2.5-flash", vision: true },
  openrouter: { title: "OpenRouter (любые модели одним ключом)", model: "deepseek/deepseek-chat", vision: false },
  groq: { title: "Groq", model: "llama-3.3-70b-versatile", vision: false },
  mistral: { title: "Mistral", model: "mistral-small-latest", vision: false },
  custom: { title: "Другой (совместимый с OpenAI API)", model: "", vision: false },
};
const SERVER_OK = { v: null };

function deckList() { const ids = S.meta.order.filter(id => S.decks[id]); Object.keys(S.decks).forEach(id => { if (!ids.includes(id)) ids.push(id); }); return ids.map(id => S.decks[id]); }
function deckMaterials(deck) { return Object.values(S.materials).filter(m => m.deckId === deck.id).sort((a, b) => a.addedAt - b.addedAt); }
function chunkById(cid) { const [mid, n] = String(cid).split(":"); const m = S.materials[mid]; if (!m) return null; const c = m.chunks[+n]; return c == null ? null : { mat: m, n: +n, text: c }; }
function isPro() { return STANDALONE || !!(ACC && ACC.user && ACC.user.plan === "pro"); }
function serverAi() { return !STANDALONE && !!(AICFG.useServer && isPro() && ACC && ACC.user && ACC.user.server_ai); }
function aiOn() { return serverAi() || !!(AICFG.provider && (AICFG.provider === "custom" ? AICFG.base_url : AICFG.key)); }
function visionOn() { if (serverAi()) return true; const p = PROVIDERS[AICFG.provider]; return !!(p && (p.vision || AICFG.provider === "custom" || AICFG.provider === "openrouter")); }

/* --- сервер --- */
async function api(method, path, body, signal) {
  if (STANDALONE) throw { code: "offline", message: "Автономная версия: сервера нет" };
  const h = { "Content-Type": "application/json" };
  if (ACC && ACC.token) h.Authorization = "Bearer " + ACC.token;
  let r;
  try { r = await fetch(API + path, { method, headers: h, body: body !== undefined ? JSON.stringify(body) : undefined, signal }); }
  catch (e) { if (e && e.name === "AbortError") throw { code: "cancelled" }; throw { code: "offline", message: "Нет связи с сервером. Проверь интернет" }; }
  let j = {}; try { j = await r.json(); } catch (e) { }
  if (!r.ok) {
    if (r.status === 401 && j.error === "auth" && ACC) { ACC = null; LS.set("bk:auth", null); updateSide(); }
    throw { code: j.error || "http_" + r.status, message: j.message || "Сервер ответил ошибкой " + r.status };
  }
  return j;
}
function setAccount(acc) { ACC = acc; LS.set("bk:auth", acc); updateSide(); }
async function refreshMe() {
  if (!ACC) return;
  try { const j = await api("GET", "/api/me"); setAccount({ token: ACC.token, user: j.user }); SERVER_OK.v = true; }
  catch (e) { if (e.code === "offline") SERVER_OK.v = false; }
}

/* --- сохранение: локально сразу, на сервер (Pro) пачками --- */
function touch(key) {
  _pristine = false; const now = Date.now();
  if (key === "meta") S.meta._upd = now;
  else if (key.startsWith("deck-") && S.decks[key.slice(5)]) S.decks[key.slice(5)]._upd = now;
  else if (key.startsWith("mat-") && S.materials[key.slice(4)]) S.materials[key.slice(4)]._upd = now;
  dirty.add(key); saveLocalSoon(); saveCloudSoon();
}
let _lt = 0, _ct = 0;
function saveLocalSoon() { clearTimeout(_lt); _lt = setTimeout(() => { try { localStorage.setItem("biletkart:v1", JSON.stringify(S)); } catch (e) { toast("Память браузера заполнена: удали большие материалы или включи синхронизацию", "err"); } }, 400); }
function saveCloudSoon() { clearTimeout(_ct); _ct = setTimeout(flushCloud, 1500); }
let _flushing = false;
async function flushCloud() {
  if (STANDALONE || !cloudReady || !isPro() || _flushing) return;
  _flushing = true;
  try {
    for (const key of Array.from(removed)) { removed.delete(key); try { await api("DELETE", "/api/sync/" + key); } catch (e) { if (e.code === "offline") { removed.add(key); break; } } }
    for (const key of Array.from(dirty)) {
      dirty.delete(key);
      let body = null;
      if (key === "meta") body = { kind: "meta", meta: S.meta };
      else if (key.startsWith("deck-")) { const d = S.decks[key.slice(5)]; if (d) body = { kind: "deck", deck: d }; }
      else if (key.startsWith("mat-")) { const m = S.materials[key.slice(4)]; if (m) body = { kind: "mat", mat: m }; }
      if (!body) continue;
      try { await api("PUT", "/api/sync/" + key, body); }
      catch (e) {
        if (e.code === "offline") { dirty.add(key); setSync("warn", "нет связи, сохраню позже"); break; }
        if (e.code === "need_pro") { cloudReady = false; break; }
        toast(e.message || "Не удалось синхронизировать", "err");
      }
    }
  } finally { _flushing = false; }
  if (cloudReady && (dirty.size || removed.size)) saveCloudSoon(); else if (cloudReady) setSync("on", "синхронизировано");
}
async function syncPull() {
  if (!isPro()) { cloudReady = false; updateSide(); return; }
  setSync("warn", "синхронизация…");
  try {
    const { docs } = await api("GET", "/api/sync");
    if (_pristine && docs.length) { S = { decks: {}, materials: {}, meta: defaultMeta() }; }
    const seen = new Set();
    for (const d of docs) {
      const v = d.body || {}; seen.add(d.key);
      if (v.kind === "deck" && v.deck) { const loc = S.decks[v.deck.id]; if (!loc || (v.deck._upd || 0) > (loc._upd || 0)) S.decks[v.deck.id] = v.deck; else if ((loc._upd || 0) > (v.deck._upd || 0)) dirty.add(d.key); }
      else if (v.kind === "mat" && v.mat) { const loc = S.materials[v.mat.id]; if (!loc || (v.mat._upd || 0) > (loc._upd || 0)) S.materials[v.mat.id] = v.mat; else if ((loc._upd || 0) > (v.mat._upd || 0)) dirty.add(d.key); }
      else if (v.kind === "meta" && v.meta) { if ((v.meta._upd || 0) > (S.meta._upd || 0)) S.meta = Object.assign(defaultMeta(), v.meta); else if ((S.meta._upd || 0) > (v.meta._upd || 0)) dirty.add("meta"); }
    }
    if (!_pristine || !docs.length) {
      Object.keys(S.decks).forEach(id => { if (!seen.has("deck-" + id)) dirty.add("deck-" + id); });
      Object.keys(S.materials).forEach(id => { if (!seen.has("mat-" + id)) dirty.add("mat-" + id); });
      if (!seen.has("meta")) dirty.add("meta");
    }
    cloudReady = true; saveLocalSoon(); setSync("on", "синхронизировано");
    if (["decks", "deck", "stats"].includes(UI.view)) render();
    flushCloud();
  } catch (e) { setSync("warn", e.code === "offline" ? "нет связи, работаю на устройстве" : "синхронизация недоступна"); }
}
function setSync(kind, text) { const el = $("#syncStat"); if (el) el.innerHTML = `<span class="dot ${kind}"></span>данные: ${esc(text)}`; }
function updateSide() {
  const p = $("#planStat"); if (p) p.innerHTML = ACC ? (isPro() ? `<span class="lock">PRO</span> ${esc(ACC.user.name || ACC.user.email)}` : esc(ACC.user.name || ACC.user.email)) : "без аккаунта";
  if (!isPro()) setSync("", "на этом устройстве");
  const a = $("#aiStat"); if (a) a.innerHTML = aiOn() ? `<span class="dot ai"></span>ИИ: ${esc(serverAi() ? "встроенный" : (PROVIDERS[AICFG.provider] || {}).title || AICFG.provider)}` : `<span class="dot warn"></span>ИИ: не подключён`;
}
function defaultMeta() { return { order: [], days: {}, exams: [], newToday: {}, settings: { newPerSession: 20, rate: 1 } }; }
let _pristine = true;

/* ============ интервальные повторения (упрощённый SM-2) ============ */
function schedule(c, g, preview = false) {
  let ivl = c.ivl || 0, ease = c.ease || 2.5, reps = c.reps || 0;
  if (g === 0) { reps = 0; ivl = 10 / 1440; ease = Math.max(1.3, ease - 0.2); }
  else {
    if (reps === 0) ivl = g === 1 ? 1 : g === 2 ? 1 : 3;
    else if (reps === 1) ivl = g === 1 ? 2 : g === 2 ? 4 : 6;
    else ivl = Math.max(ivl + 1, ivl * ease * (g === 1 ? 0.55 : g === 3 ? 1.3 : 1));
    ease = clamp(ease + (g === 1 ? -0.15 : g === 3 ? 0.15 : 0), 1.3, 3.2);
    reps++;
  }
  if (preview) return ivl;
  c.ivl = ivl; c.ease = ease; c.reps = reps; c.lapses = (c.lapses || 0) + (g === 0 ? 1 : 0);
  c.due = Date.now() + ivl * DAY; c.last = Date.now();
  c.hist = (c.hist || []).concat(g).slice(-6);
}
function cardMastery(c) {
  if (!c.hist || !c.hist.length) return null;
  let s = 0, w = 0; c.hist.slice(-5).forEach((g, i) => { s += (i + 1) * (g / 3); w += i + 1; });
  let m = s / w;
  if (c.due && Date.now() > c.due) m *= Math.max(0.55, 1 - ((Date.now() - c.due) / DAY) * 0.04);
  return m;
}
function ticketStat(deck, t) {
  const cs = deck.cards.filter(c => c.t === t.id);
  if (!cs.length) return { m: t.exam != null ? t.exam / 100 : null, n: 0, seen: 0, due: 0 };
  const ms = cs.map(cardMastery), seen = ms.filter(x => x != null).length;
  let m = seen ? sum(ms.map(x => x ?? 0)) / cs.length : null;
  if (t.exam != null) m = m == null ? t.exam / 100 : 0.7 * m + 0.3 * (t.exam / 100);
  const due = cs.filter(c => c.hist && c.hist.length && c.due <= Date.now()).length;
  return { m, n: cs.length, seen, due };
}
function lvClass(m) { return m == null ? "lv-none" : m < 0.45 ? "lv-weak" : m < 0.75 ? "lv-mid" : "lv-ok"; }
function lvLabel(m) { return m == null ? "не начат" : m < 0.45 ? "слабый" : m < 0.75 ? "в процессе" : "уверенно"; }
function lvColor(m) { return m == null ? "var(--lv0)" : m < 0.45 ? "var(--bad)" : m < 0.75 ? "var(--amber)" : "var(--cyan)"; }
function deckDue(deck) { const now = Date.now(); return deck.cards.filter(c => c.hist && c.hist.length && c.due <= now).length; }
function deckNew(deck) { return deck.cards.filter(c => !c.hist || !c.hist.length).length; }

/* ============ рендер «богатого» контента: Markdown + LaTeX + код + схемы + графики ============ */
function configLibs() { if (window.marked && !configLibs.m) { marked.use({ gfm: true, breaks: true }); configLibs.m = 1; } if (window.hljs) hljs.configure({ ignoreUnescapedHTML: true }); }
function renderRich(src) {
  const store = []; let s = String(src || "");
  const put = (o, tag) => { store.push(o); return "@@" + tag + (store.length - 1) + "@@"; };
  s = s.replace(/(^|\n)(```|~~~)[ \t]*([\w+#-]*)[^\n]*\n([\s\S]*?)\n?\2[ \t]*(?=\n|$)/g, (m, pre, f, lang, body) => {
    lang = (lang || "").toLowerCase();
    const k = lang === "mermaid" ? "mermaid" : (lang === "graph" || lang === "plot") ? "graph" : "code";
    return pre + "\n" + put({ k, lang, v: body }, "B") + "\n";
  });
  s = s.replace(/`([^`\n]+)`/g, (m, v) => put({ k: "icode", v }, "I"));
  s = s.replace(/\$\$([\s\S]+?)\$\$|\\\[([\s\S]+?)\\\]/g, (m, a, b) => put({ k: "dmath", v: a ?? b }, "M"));
  s = s.replace(/\\\(([\s\S]+?)\\\)|\$(?![\s$])([^$\n]+?)(?<!\s)\$(?!\d)/g, (m, a, b) => put({ k: "imath", v: a ?? b }, "I"));
  s = s.replace(/\\ce\{((?:[^{}]|\{[^{}]*\})*)\}/g, (m) => put({ k: "imath", v: m }, "I"));
  let html;
  if (window.marked && window.DOMPurify) html = DOMPurify.sanitize(marked.parse(s));
  else html = "<p>" + esc(s).replace(/\n/g, "<br>") + "</p>";
  html = html.replace(/<p>\s*(@@[BM]\d+@@)\s*<\/p>/g, "$1");
  html = html.replace(/@@([BIM])(\d+)@@/g, (m, t, i) => {
    const it = store[+i]; if (!it) return "";
    switch (it.k) {
      case "code": { const lg = /^[\w+#-]+$/.test(it.lang) ? it.lang : ""; return `<pre class="code"><code${lg ? ` class="language-${esc(lg)}"` : ""}>${esc(it.v)}</code></pre>`; }
      case "mermaid": return `<div class="mermaid-box" data-src="${esc(it.v)}"><span class="muted mono">строю схему…</span></div>`;
      case "graph": return `<div class="graph-box" data-src="${esc(it.v)}"><canvas></canvas></div>`;
      case "icode": return `<code>${esc(it.v)}</code>`;
      case "dmath": return `<div class="math-d">\\[${esc(it.v)}\\]</div>`;
      case "imath": return `<span class="math-i">\\(${esc(it.v)}\\)</span>`;
    }
    return "";
  });
  return html;
}
function hydrate(root) {
  if (!root) return;
  if (window.hljs) $$("pre.code code[class*=language-]", root).forEach(el => { if (!el.dataset.hl) { el.dataset.hl = 1; try { hljs.highlightElement(el); } catch (e) { } } });
  $$(".mermaid-box[data-src]", root).forEach(renderMermaid);
  $$(".graph-box[data-src]", root).forEach(renderGraph);
  typeset(root);
}
let _mj = Promise.resolve();
function waitMJ() { return new Promise(res => { const t0 = Date.now(); (function chk() { if (window.MathJax && MathJax.typesetPromise && MathJax.startup && MathJax.startup.promise) return MathJax.startup.promise.then(() => res(true)); if (Date.now() - t0 > 20000) return res(false); setTimeout(chk, 150); })(); }); }
function typeset(el) {
  if (!el.querySelector(".math-i,.math-d")) return;
  _mj = _mj.then(async () => { const ok = await waitMJ(); if (!ok || !el.isConnected) return; try { await MathJax.typesetPromise([el]); } catch (e) { } });
}
let _mmInit = false;
async function renderMermaid(box) {
  const src = box.dataset.src; box.removeAttribute("data-src");
  const id = "mm" + uid();
  try {
    await loadLib("mermaid");
    if (!_mmInit) {
      mermaid.initialize({ startOnLoad: false, securityLevel: "strict", theme: "base", fontFamily: "IBM Plex Sans, sans-serif",
        themeVariables: { background: "#070912", primaryColor: "#16203a", primaryBorderColor: "#3ee6f0", primaryTextColor: "#e4e7f5", lineColor: "#8b91b4", secondaryColor: "#2a1430", secondaryBorderColor: "#ff3d9a", tertiaryColor: "#11152a", textColor: "#e4e7f5", actorBkg: "#16203a", actorBorder: "#3ee6f0", actorTextColor: "#e4e7f5", signalColor: "#8b91b4", signalTextColor: "#e4e7f5", noteBkgColor: "#2a1430", noteTextColor: "#e4e7f5", noteBorderColor: "#ff3d9a", fontSize: "14px" } });
      _mmInit = true;
    }
    const { svg } = await mermaid.render(id, src);
    box.innerHTML = svg;
  } catch (e) {
    document.getElementById("d" + id)?.remove(); document.getElementById(id)?.remove();
    box.innerHTML = `<div class="warn">Схема не построилась: проверь синтаксис Mermaid</div><pre class="code"><code>${esc(src)}</code></pre>`;
  }
}
const GCOL = ["#3ee6f0", "#ff3d9a", "#ffc857", "#4be3a6"];
async function renderGraph(box) {
  const src = box.dataset.src; box.removeAttribute("data-src");
  const fns = []; let xr = [-6, 6], yr = null;
  for (const raw of src.split("\n")) {
    const line = raw.trim(); if (!line || line.startsWith("#")) continue;
    let m;
    if ((m = line.match(/^x\s*:\s*(.+?)\s*\.\.\s*(.+)$/i))) { const a = parseRange(m[1]), b = parseRange(m[2]); if (isFinite(a) && isFinite(b) && b > a) xr = [a, b]; continue; }
    if ((m = line.match(/^y\s*:\s*(.+?)\s*\.\.\s*(.+)$/i))) { const a = parseRange(m[1]), b = parseRange(m[2]); if (isFinite(a) && isFinite(b) && b > a) yr = [a, b]; continue; }
    m = line.match(/^(?:y|[a-zа-я]\(x\))\s*=\s*(.+)$/i);
    fns.push(m ? m[1] : line);
  }
  try { await loadLib("mathjs"); } catch (e) { box.innerHTML = `<div class="warn">Не удалось загрузить построитель графиков</div>`; return; }
  const comp = [];
  for (const f of fns.slice(0, 4)) { try { comp.push({ f, c: math.compile(f) }); } catch (e) { comp.push({ f, c: null }); } }
  const cv = box.querySelector("canvas"); const W = Math.max(280, box.clientWidth - 16), H = 240, dpr = window.devicePixelRatio || 1;
  cv.width = W * dpr; cv.height = H * dpr; cv.style.height = H + "px";
  const g = cv.getContext("2d"); g.scale(dpr, dpr);
  const N = 500, pts = comp.map(({ c }) => { const a = []; for (let i = 0; i <= N; i++) { const x = xr[0] + (xr[1] - xr[0]) * i / N; let y = NaN; if (c) { try { const v = c.evaluate({ x, e: Math.E, pi: Math.PI }); y = typeof v === "number" ? v : NaN; } catch (e) { } } a.push([x, isFinite(y) ? y : NaN]); } return a; });
  if (!yr) { const ys = pts.flat().map(p => p[1]).filter(isFinite).sort((a, b) => a - b); if (ys.length) { let lo = ys[Math.floor(ys.length * 0.03)], hi = ys[Math.ceil(ys.length * 0.97) - 1]; if (hi - lo < 1e-6) { lo -= 1; hi += 1; } const pad = (hi - lo) * 0.12; yr = [lo - pad, hi + pad]; } else yr = [-1, 1]; }
  const L = 34, R = 10, T = 10, B = 22, pw = W - L - R, ph = H - T - B;
  const X = x => L + (x - xr[0]) / (xr[1] - xr[0]) * pw, Y = y => T + (1 - (y - yr[0]) / (yr[1] - yr[0])) * ph;
  const step = r => { const raw = r / 6, p = Math.pow(10, Math.floor(Math.log10(raw))), m = raw / p; return (m < 1.5 ? 1 : m < 3.5 ? 2 : m < 7.5 ? 5 : 10) * p; };
  g.font = "10px JetBrains Mono, monospace"; g.lineWidth = 1;
  const sx = step(xr[1] - xr[0]), sy = step(yr[1] - yr[0]);
  for (let x = Math.ceil(xr[0] / sx) * sx; x <= xr[1] + 1e-9; x += sx) { g.strokeStyle = "rgba(139,145,180,.12)"; g.beginPath(); g.moveTo(X(x), T); g.lineTo(X(x), T + ph); g.stroke(); g.fillStyle = "#5d6388"; g.textAlign = "center"; g.fillText(+x.toFixed(4) + "", X(x), H - 6); }
  for (let y = Math.ceil(yr[0] / sy) * sy; y <= yr[1] + 1e-9; y += sy) { g.strokeStyle = "rgba(139,145,180,.12)"; g.beginPath(); g.moveTo(L, Y(y)); g.lineTo(L + pw, Y(y)); g.stroke(); g.fillStyle = "#5d6388"; g.textAlign = "right"; g.fillText(+y.toFixed(4) + "", L - 5, Y(y) + 3); }
  g.strokeStyle = "rgba(228,231,245,.45)";
  if (xr[0] < 0 && xr[1] > 0) { g.beginPath(); g.moveTo(X(0), T); g.lineTo(X(0), T + ph); g.stroke(); }
  if (yr[0] < 0 && yr[1] > 0) { g.beginPath(); g.moveTo(L, Y(0)); g.lineTo(L + pw, Y(0)); g.stroke(); }
  g.save(); g.beginPath(); g.rect(L, T, pw, ph); g.clip();
  pts.forEach((a, i) => { g.strokeStyle = GCOL[i % 4]; g.lineWidth = 2; g.shadowColor = GCOL[i % 4]; g.shadowBlur = 6; g.beginPath(); let pen = false, prev = null; for (const [x, y] of a) { if (!isFinite(y) || (prev != null && Math.abs(y - prev) > (yr[1] - yr[0]) * 3)) { pen = false; prev = isFinite(y) ? y : null; continue; } const px = X(x), py = Y(y); if (!pen) { g.moveTo(px, py); pen = true; } else g.lineTo(px, py); prev = y; } g.stroke(); });
  g.restore();
  const leg = document.createElement("div"); leg.className = "graph-leg";
  comp.forEach(({ f, c }, i) => { const s = document.createElement("span"); s.style.color = GCOL[i % 4]; s.textContent = (c ? "y = " : "ошибка: ") + f; leg.appendChild(s); });
  box.appendChild(leg);
}
function parseRange(v) { v = String(v).trim().toLowerCase().replace(/\s/g, ""); const m = v.match(/^(-?)(\d*\.?\d*)\*?(pi|π)?$/); if (!m) return NaN; const k = m[2] === "" ? 1 : Number(m[2]); return (m[1] ? -1 : 1) * k * (m[3] ? Math.PI : 1); }
function plain(md) { // текст для озвучки
  return String(md || "").replace(/```[\s\S]*?```|~~~[\s\S]*?~~~/g, " (фрагмент кода) ")
    .replace(/\\frac\{([^{}]*)\}\{([^{}]*)\}/g, "$1 делить на $2").replace(/\^\{?2\}?/g, " в квадрате").replace(/\^\{?3\}?/g, " в кубе")
    .replace(/\\lim_\{?([^}\s]*)\}?/g, "предел при $1 ").replace(/\\to/g, " стремится к ").replace(/\\infty/g, "бесконечность")
    .replace(/\\int/g, "интеграл ").replace(/\\sum/g, "сумма ").replace(/\\sqrt\{([^{}]*)\}/g, "корень из $1").replace(/\\(sin|cos|tg|ln|log)/g, "$1")
    .replace(/\\[a-zA-Z]+/g, " ").replace(/[\\${}_*#>|`~]/g, " ").replace(/\s+/g, " ").trim().slice(0, 1900);
}

/* ============ ИИ ============ */
const AI_ERR = {
  offline: "Нет связи с сервером. Проверь интернет", rate_limited: "Слишком много запросов. Подожди минуту",
  cancelled: "Остановлено", need_pro: "Это доступно в Pro", no_key: "Укажи API-ключ в профиле",
};
const aiErrText = e => (e && e.message && e.code !== "cancelled") ? e.message : (AI_ERR[e && e.code] || "Не получилось, попробуй ещё раз");
async function fileToDataUrl(file) {
  const bmp = await createImageBitmap(file);
  const k = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
  const c = document.createElement("canvas"); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
  c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
  return c.toDataURL("image/jpeg", 0.85);
}

/* --- прямой вызов провайдера из браузера (без нашего сервера) --- */
const AI_BASES = { deepseek: "https://api.deepseek.com/v1", openai: "https://api.openai.com/v1", anthropic: "https://api.anthropic.com/v1", gemini: "https://generativelanguage.googleapis.com/v1beta", openrouter: "https://openrouter.ai/api/v1", groq: "https://api.groq.com/openai/v1", mistral: "https://api.mistral.ai/v1" };
function splitDataUrl(u) { const m = /^data:(image\/(?:png|jpeg|webp|gif));base64,([A-Za-z0-9+\/=]+)$/.exec(u || ""); if (!m) throw { code: "bad_image", message: "Неверный формат изображения" }; return [m[1], m[2]]; }
async function directAI(c, prompt, images, maxTokens, signal) {
  const prov = c.provider, P = PROVIDERS[prov]; if (!P) throw { code: "bad_provider", message: "Неизвестный провайдер" };
  const base = String(c.base_url || AI_BASES[prov] || "").replace(/\/$/, ""), model = c.model || P.model;
  if (!base || !model) throw { code: "bad_config", message: "Укажи адрес API и название модели" };
  if (!c.key && prov !== "custom") throw { code: "no_key", message: "Не указан API-ключ" };
  images = images || [];
  if (images.length && !(P.vision || prov === "custom" || prov === "openrouter")) throw { code: "no_vision", message: "Эта модель не понимает изображения. Выбери Claude, OpenAI или Gemini" };
  let url, headers = { "Content-Type": "application/json" }, body;
  if (prov === "anthropic") {
    url = base + "/messages"; headers["x-api-key"] = c.key; headers["anthropic-version"] = "2023-06-01"; headers["anthropic-dangerous-direct-browser-access"] = "true";
    const content = images.map(splitDataUrl).map(([mt, d]) => ({ type: "image", source: { type: "base64", media_type: mt, data: d } })); content.push({ type: "text", text: prompt });
    body = { model, max_tokens: maxTokens, messages: [{ role: "user", content }] };
  } else if (prov === "gemini") {
    url = `${base}/models/${encodeURIComponent(model)}:generateContent`; headers["x-goog-api-key"] = c.key;
    const parts = images.map(splitDataUrl).map(([mt, d]) => ({ inline_data: { mime_type: mt, data: d } })); parts.push({ text: prompt });
    body = { contents: [{ role: "user", parts }], generationConfig: { maxOutputTokens: maxTokens } };
  } else {
    url = base + "/chat/completions"; if (c.key) headers.Authorization = "Bearer " + c.key;
    const content = images.length ? [{ type: "text", text: prompt }, ...images.map(u => ({ type: "image_url", image_url: { url: u } }))] : prompt;
    body = { model, max_tokens: maxTokens, messages: [{ role: "user", content }] };
  }
  let r;
  try { r = await fetch(url, { method: "POST", headers, body: JSON.stringify(body), signal }); }
  catch (e) { if (e && e.name === "AbortError") throw { code: "cancelled" }; throw { code: "provider_unreachable", message: "Не достучался до провайдера. Проверь интернет. Если это локальная модель (Ollama), разреши в ней доступ с этой страницы (OLLAMA_ORIGINS=*)" }; }
  let j = {}; try { j = await r.json(); } catch (e) { }
  if (!r.ok) {
    const er = j.error || j, msg = (er && er.message) || (typeof er === "string" ? er : "");
    if (r.status === 401 || r.status === 403) throw { code: "bad_key", message: "Провайдер отклонил ключ: " + (msg || "неверный ключ") };
    if (r.status === 402) throw { code: "no_balance", message: "На счёте у провайдера закончились деньги. Пополни баланс в его личном кабинете или выбери другого провайдера в профиле" };
    if (r.status === 429) throw { code: "provider_limit", message: "У провайдера закончился лимит или баланс: " + msg };
    if (r.status === 404) throw { code: "bad_model", message: "Модель или адрес не найдены: " + msg };
    throw { code: "provider_error", message: `Ошибка провайдера (${r.status}): ${msg}` };
  }
  let text = "";
  if (prov === "anthropic") text = (j.content || []).filter(b => b.type === "text").map(b => b.text).join("");
  else if (prov === "gemini") { const cd = (j.candidates || [])[0]; text = cd ? ((cd.content && cd.content.parts) || []).map(p => p.text || "").join("") : ""; }
  else { const m = ((j.choices || [])[0] || {}).message || {}; text = m.content || ""; if (Array.isArray(text)) text = text.map(x => x.text || "").join(""); }
  text = (text || "").trim(); if (!text) throw { code: "empty", message: "Нейросеть вернула пустой ответ" };
  return text;
}
async function ai(prompt, o = {}) {
  if (!aiOn()) { openAiSetup(); throw { code: "cancelled" }; }
  const body = serverAi() ? { use_server_ai: true, prompt } : { provider: AICFG.provider, model: AICFG.model, key: AICFG.key, base_url: AICFG.base_url, prompt };
  if (o.images) body.images = await Promise.all(Array.from(o.images).map(fileToDataUrl));
  if (o.signal && o.signal.aborted) throw { code: "cancelled" };
  const text = STANDALONE ? await directAI(AICFG, prompt, body.images, 4000, o.signal) : (await api("POST", "/api/ai", body, o.signal)).text;
  if (o.onText) o.onText({ text, delta: text });
  return text;
}
function openAiSetup() {
  openModal(`<div class="modal-h"><div><div class="eyebrow m">нейросеть</div><h2>Подключи свою нейросеть</h2></div><button class="ib" data-act="close" aria-label="Закрыть">✕</button></div>
    <p>Карточки, проверку ответов и объяснения делает нейросеть, которую ты выберешь: DeepSeek, ChatGPT, Claude, Gemini и другие. Нужен только API-ключ из личного кабинета провайдера. Это бесплатно в любом тарифе.</p>
    <p class="note">Ключ хранится только на этом устройстве. Сервер БилетКарт передаёт запрос провайдеру и не сохраняет ключ.</p>
    <div class="modal-f"><button class="btn ghost" data-act="close">Позже</button><button class="btn pri" data-act="goto-ai">Открыть настройки</button></div>`);
}
function needPro(what) {
  openModal(`<div class="modal-h"><div><div class="eyebrow" style="color:var(--yellow)">БилетКарт Pro</div><h2>${esc(what)} — в Pro</h2></div><button class="ib" data-act="close" aria-label="Закрыть">✕</button></div>
    <div class="upsell" style="padding:18px 20px"><b>Что даёт Pro</b><ul>
      <li>Синхронизация колод между телефоном и компьютером</li>
      <li>Симулятор экзамена: таймер, ИИ-экзаменатор, дополнительный вопрос</li>
      <li>Генератор комплектов экзаменационных билетов</li>
      <li>Аудио-прогон: приложение читает вопросы и ответы вслух</li>
      ${(window.BK_CONFIG && BK_CONFIG.serverAi) ? "<li>Встроенный ИИ без своего ключа</li>" : ""}</ul></div>
    <div class="modal-f"><button class="btn ghost" data-act="close">Не сейчас</button><button class="btn pro" data-act="goto-pro">Подключить Pro</button></div>`);
}

function parseTagged(text, keys) {
  const out = {}; let cur = null;
  const re = new RegExp("^\\s*(?:[*_]{1,2})?(" + keys.join("|") + ")(?:[*_]{1,2})?\\s*:\\s?(.*)$");
  for (const line of String(text).split("\n")) {
    const m = line.match(re);
    if (m) { cur = m[1]; out[cur] = (out[cur] != null ? out[cur] + "\n" : "") + m[2]; }
    else if (cur) out[cur] += "\n" + line;
  }
  for (const k in out) out[k] = out[k].trim();
  return out;
}
const FORMAT_RULES = `Оформление текста: Markdown. Формулы — LaTeX: внутри строки \\( ... \\), отдельной строкой \\[ ... \\]. Химические формулы и реакции — \\ce{...}. Код — блок \`\`\`язык. Если тему лучше показать схемой (процесс, алгоритм, классификация) — короткий блок \`\`\`mermaid (flowchart LR или sequenceDiagram, до 8 узлов, подписи без кавычек и скобок). Если уместен график функции — блок \`\`\`graph, внутри строки вида "y = выражение" (синтаксис math.js: sin(x), x^2, exp(x)) и строка "x: от..до". Схемы и графики добавляй только там, где они реально помогают.`;

/* --- поиск подходящих фрагментов материала (простой BM25-подобный скоринг) --- */
const STOP = new Set("и в во на с со к ко по о об от до за из у не что как это для или а но то же ли бы при над под между также который которые его ее их они она он мы вы ты есть был была были быть the of and is to in for with on".split(" "));
function toks(s) { return (String(s).toLowerCase().replace(/ё/g, "е").match(/[a-zа-яәіңғүұқөһ0-9]+/g) || []).filter(w => w.length > 2 && !STOP.has(w)).map(w => w.length > 6 ? w.slice(0, 6) : w); }
function retrieve(deck, query, k = 6) {
  const all = []; deckMaterials(deck).forEach(m => m.chunks.forEach((text, n) => all.push({ id: m.id + ":" + n, mat: m, n, text })));
  if (!all.length) return [];
  const docs = all.map(c => { const tf = new Map(); toks(c.text).forEach(w => tf.set(w, (tf.get(w) || 0) + 1)); return tf; });
  const df = new Map(); docs.forEach(tf => tf.forEach((v, w) => df.set(w, (df.get(w) || 0) + 1)));
  const q = Array.from(new Set(toks(query))); const N = all.length;
  const scored = all.map((c, i) => { let s = 0; q.forEach(w => { const tf = docs[i].get(w); if (tf) s += Math.log(1 + N / df.get(w)) * (1 + Math.log(tf)); }); return { c, s }; }).filter(x => x.s > 0).sort((a, b) => b.s - a.s);
  const pick = scored.slice(0, k).map(x => x.c);
  if (pick[0]) { const nb = all.find(c => c.mat === pick[0].mat && c.n === pick[0].n + 1); if (nb && !pick.includes(nb) && pick.length < k + 1) pick.push(nb); }
  let total = 0; return pick.filter(c => (total += c.text.length) < 14000);
}
function fragBlock(frags) { return frags.map((f, i) => `[F${i + 1}] (${f.mat.name}, ¶${f.n + 1})\n${f.text}`).join("\n\n"); }
function srcLabel(cid) { const c = chunkById(cid); return c ? `¶${c.n + 1} · ${c.mat.name}` : "источник удалён"; }

/* ============ интерфейс: тосты, модалки ============ */
function toast(msg, kind = "", action) {
  const w = $("#toasts"), t = document.createElement("div"); t.className = "toast " + kind;
  const sp = document.createElement("span"); sp.textContent = msg; t.appendChild(sp);
  if (action) { const b = document.createElement("button"); b.className = "btn sm"; b.textContent = action.label; b.onclick = () => { action.fn(); t.remove(); }; t.appendChild(b); }
  w.appendChild(t); setTimeout(() => t.remove(), action ? 7000 : 4200);
}
let _modalClose = null;
function openModal(html, { wide = false, onClose } = {}) {
  closeModal();
  const root = $("#modalRoot");
  root.innerHTML = `<div class="modal-bg" data-bg><div class="modal ${wide ? "wide" : ""}" role="dialog" aria-modal="true">${html}</div></div>`;
  const bg = root.firstElementChild;
  bg.addEventListener("mousedown", e => { if (e.target === bg) closeModal(); });
  _modalClose = onClose || null;
  const f = bg.querySelector("[autofocus],textarea,input"); if (f) setTimeout(() => f.focus(), 30);
  return bg.firstElementChild;
}
function closeModal() { const r = $("#modalRoot"); if (r.firstChild) { r.innerHTML = ""; if (_modalClose) { const f = _modalClose; _modalClose = null; f(); } } }
const ICON = {
  mic: `<svg viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>`,
  spk: `<svg viewBox="0 0 24 24"><path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/></svg>`,
  stop: `<svg viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12"/></svg>`,
  edit: `<svg viewBox="0 0 24 24"><path d="M4 20h4L19 9l-4-4L4 16z"/></svg>`,
  del: `<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/></svg>`,
  spark: `<svg viewBox="0 0 24 24"><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M6 18l2.5-2.5M15.5 8.5L18 6"/></svg>`,
  chev: `<svg viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"/></svg>`,
  plus: `<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>`,
  gear: `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/></svg>`,
};

/* --- голос: диктовка ответа и озвучка --- */
let _dictTarget = null, _dictBtn = null;
function wireDictation(d) {
  d.onPartial(({ text }) => { const p = _dictTarget && _dictTarget.parentElement.parentElement.querySelector(".partial"); if (p) p.textContent = text; });
  d.onFinal(({ text }) => { if (_dictTarget) { const v = _dictTarget.value; _dictTarget.value = v + (v && !/\s$/.test(v) ? " " : "") + text; _dictTarget.dispatchEvent(new Event("input")); } const p = _dictTarget && _dictTarget.parentElement.parentElement.querySelector(".partial"); if (p) p.textContent = ""; });
  d.onState(({ state }) => { if (_dictBtn) _dictBtn.classList.toggle("live", state === "listening"); if (state !== "listening") { _dictBtn = null; } });
}
function micBtn(target) { return CAP.dict ? `<button type="button" class="ib" data-act="mic" data-target="${esc(target)}" title="Ответить голосом" aria-label="Ответить голосом">${ICON.mic}</button>` : ""; }
function toggleMic(btn) {
  const d = CAP.dict; if (!d) return;
  if (btn.classList.contains("live")) { d.stop().catch(() => { }); btn.classList.remove("live"); return; }
  _dictTarget = $(btn.dataset.target); _dictBtn = btn;
  d.start().catch(e => { btn.classList.remove("live"); if (e && e.code === "not_granted") { CAP.dict = null; toast("Микрофон не разрешён, отвечай текстом", "err"); rerenderSoft(); } });
}
let _speaking = null;
function speak(text, btn) {
  const t = CAP.tts; if (!t) return Promise.resolve();
  if (_speaking === btn && btn) { t.stop(); return Promise.resolve(); }
  $$(".ib.live[data-act=speak]").forEach(b => b.classList.remove("live"));
  _speaking = btn || null; if (btn) btn.classList.add("live");
  return t.speak(plain(text)).catch(e => { if (e && e.code === "not_granted") { CAP.tts = null; rerenderSoft(); } })
    .finally(() => { if (btn) btn.classList.remove("live"); if (_speaking === btn) _speaking = null; });
}
/* --- голос: адаптеры для браузера и для приложения на телефоне (Capacitor) --- */
function isNative() { return !!(window.Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform()); }
function makeTTS() {
  const P = isNative() && Capacitor.Plugins && Capacitor.Plugins.TextToSpeech;
  const rate = () => (S.meta.settings && S.meta.settings.rate) || 1;
  if (P) return { speak: t => P.speak({ text: t, lang: "ru-RU", rate: rate() }), stop: () => P.stop().catch(() => { }) };
  if (!("speechSynthesis" in window)) return null;
  return {
    speak: t => new Promise((res, rej) => {
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(t); u.lang = "ru-RU"; u.rate = rate();
      const v = speechSynthesis.getVoices().find(v => /^ru/i.test(v.lang)); if (v) u.voice = v;
      u.onend = () => res(); u.onerror = e => rej({ code: e.error || "tts" });
      speechSynthesis.speak(u);
    }),
    stop: () => speechSynthesis.cancel(),
  };
}
function makeDict() {
  const L = { p: [], f: [], s: [] }, emit = (k, v) => L[k].forEach(fn => { try { fn(v); } catch (e) { } });
  const d = { onPartial: fn => L.p.push(fn), onFinal: fn => L.f.push(fn), onState: fn => L.s.push(fn) };
  const P = isNative() && Capacitor.Plugins && Capacitor.Plugins.SpeechRecognition;
  if (P) {
    let last = "", h = null;
    d.start = async () => {
      const perm = await P.requestPermissions().catch(() => null);
      if (perm && perm.speechRecognition && perm.speechRecognition !== "granted") throw { code: "not_granted" };
      last = ""; h = await P.addListener("partialResults", r => { last = (r.matches && r.matches[0]) || ""; emit("p", { text: last }); });
      emit("s", { state: "listening" });
      P.start({ language: "ru-RU", partialResults: true, popup: false }).catch(() => { });
    };
    d.stop = async () => { try { await P.stop(); } catch (e) { } if (h) { h.remove(); h = null; } if (last) emit("f", { text: last }); last = ""; emit("p", { text: "" }); emit("s", { state: "idle" }); };
    return d;
  }
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition; if (!SR) return null;
  let rec = null;
  d.start = () => new Promise((res, rej) => {
    rec = new SR(); rec.lang = "ru-RU"; rec.continuous = true; rec.interimResults = true;
    rec.onresult = e => { let interim = ""; for (let i = e.resultIndex; i < e.results.length; i++) { const r = e.results[i]; if (r.isFinal) emit("f", { text: r[0].transcript.trim() }); else interim += r[0].transcript; } emit("p", { text: interim }); };
    rec.onerror = e => { if (e.error === "not-allowed" || e.error === "service-not-allowed") { emit("s", { state: "idle" }); rej({ code: "not_granted" }); } };
    rec.onend = () => emit("s", { state: "idle" });
    rec.onstart = () => { emit("s", { state: "listening" }); res(); };
    try { rec.start(); } catch (e) { rej({ code: "busy" }); }
  });
  d.stop = async () => { try { rec && rec.stop(); } catch (e) { } };
  return d;
}

/* --- резервная копия --- */
function exportBackup() {
  const data = JSON.stringify({ app: "biletkart", v: 1, at: new Date().toISOString(), state: S });
  const name = "biletkart-" + dayKey() + ".json";
  const file = new File([data], name, { type: "application/json" });
  if (isNative() && navigator.canShare && navigator.canShare({ files: [file] })) { navigator.share({ files: [file], title: "БилетКарт" }).catch(() => { }); return; }
  const a = document.createElement("a"); a.href = URL.createObjectURL(file); a.download = name; document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
}
async function importBackup(file) {
  let j; try { j = JSON.parse(await file.text()); } catch (e) { toast("Это не файл резервной копии", "err"); return; }
  const st = j && (j.state || j); if (!st || !st.decks) { toast("Это не файл резервной копии БилетКарт", "err"); return; }
  const m = openModal(`<div class="modal-h"><h2>Восстановить из копии?</h2><button class="ib" data-act="close" aria-label="Закрыть">✕</button></div>
    <p>В файле ${pl(Object.keys(st.decks).length, "колода", "колоды", "колод")}. Текущие данные на этом устройстве будут заменены.</p>
    <div class="modal-f"><button class="btn ghost" data-act="close">Отмена</button><button class="btn pri" id="bkOk">Восстановить</button></div>`);
  $("#bkOk", m).onclick = () => {
    Object.keys(S.decks).forEach(id => removed.add("deck-" + id)); Object.keys(S.materials).forEach(id => removed.add("mat-" + id));
    S = { decks: st.decks, materials: st.materials || {}, meta: Object.assign(defaultMeta(), st.meta || {}) };
    Object.keys(S.decks).forEach(id => { removed.delete("deck-" + id); touch("deck-" + id); });
    Object.keys(S.materials).forEach(id => { removed.delete("mat-" + id); touch("mat-" + id); });
    touch("meta"); closeModal(); go("decks"); toast("Данные восстановлены");
  };
}
</script>
