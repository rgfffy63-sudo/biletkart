<script>
/* ============ экран: экзамен ============ */
let EX = null, EXSET = { deckId: null, minutes: 10, k: 2, task: true }, GEN = null, GENSET = { n: 10, k: 2, task: false }, _exTimer = 0;
function exDeck() { const ds = deckList(); if (!EXSET.deckId || !S.decks[EXSET.deckId]) EXSET.deckId = ds[0] ? ds[0].id : null; return EXSET.deckId ? S.decks[EXSET.deckId] : null; }
function vExam() {
  const d = exDeck();
  if (!d) return `<header class="vh"><div><div class="eyebrow">экзамен</div><h1>Экзамен</h1></div></header><div class="empty">Сначала создай колоду с билетами.</div>`;
  if (!isPro()) return examUpsell();
  if (EX && EX.state !== "setup") return vExamRun();
  const ds = deckList(), tn = d.tickets.length;
  return `<header class="vh"><div><div class="eyebrow">экзамен</div><h1>Симулятор экзамена и генератор билетов</h1></div></header>
  <div class="row" style="margin-bottom:18px"><span class="lbl" style="margin:0">Колода</span><div class="chips">${ds.map(x => `<button class="chip" data-act="ex-deck" data-deck="${x.id}" aria-pressed="${x.id === d.id}">${esc(x.name)}</button>`).join("")}</div></div>
  <div class="setup-grid">
    <section class="panel stack"><div class="eyebrow">симулятор</div><h2>Вытянуть билет</h2>
      <p class="muted" style="margin:0;font-size:13.5px">Приложение тянет билет, чаще выбирая твои слабые темы, запускает таймер подготовки, а ИИ-экзаменатор ставит оценку и задаёт дополнительный вопрос.</p>
      <div><div class="lbl">Время на подготовку</div><div class="seg">${[5, 10, 15, 20].map(m => `<button data-act="ex-min" data-v="${m}" aria-pressed="${EXSET.minutes === m}">${m} мин</button>`).join("")}</div></div>
      <div><div class="lbl">Теоретических вопросов</div><div class="seg">${[1, 2, 3].map(k => `<button data-act="ex-k" data-v="${k}" aria-pressed="${EXSET.k === k}" ${k > tn ? "disabled" : ""}>${k}</button>`).join("")}</div></div>
      <label class="switch"><input type="checkbox" id="exTask" ${EXSET.task ? "checked" : ""}> Практическая задача от ИИ по материалам</label>
      <div class="grow"></div><div><button class="btn pri" data-act="ex-draw" ${tn ? "" : "disabled"}>Тянуть билет</button></div>
    </section>
    <section class="panel stack"><div class="eyebrow m">генератор</div><h2>Комплект экзаменационных билетов</h2>
      <p class="muted" style="margin:0;font-size:13.5px">ИИ составляет ${GENSET.n} билетов из ${pl(tn, "вопроса", "вопросов", "вопросов")} программы: темы перемешаны, каждый вопрос встречается, сложность ровная. Подойдёт для самопроверки в группе.</p>
      <div class="row"><div style="width:110px"><label class="lbl" for="genN">Билетов</label><input type="number" id="genN" min="2" max="40" value="${GENSET.n}"></div>
        <div><div class="lbl">Вопросов в билете</div><div class="seg">${[2, 3].map(k => `<button data-act="gen-k" data-v="${k}" aria-pressed="${GENSET.k === k}">${k}</button>`).join("")}</div></div></div>
      <label class="switch"><input type="checkbox" id="genTask" ${GENSET.task ? "checked" : ""}> Добавить в каждый билет задачу</label>
      <div class="grow"></div><div class="row"><button class="btn ai solid" data-act="gen-set" ${tn >= 2 && !(GEN && GEN.state === "loading") ? "" : "disabled"}>${ICON.spark} Сгенерировать с ИИ</button><button class="btn" data-act="gen-local" ${tn >= 2 ? "" : "disabled"}>Собрать без ИИ</button></div>
    </section>
  </div>
  ${GEN && GEN.deckId === d.id ? genResult() : ""}
  ${examHistory(d)}`;
}
function examUpsell() {
  return `<header class="vh"><div><div class="eyebrow">экзамен</div><h1>Симулятор экзамена</h1></div></header>
  <section class="upsell"><span class="tag pro">PRO</span><h2 style="margin-top:12px">Репетиция настоящего экзамена</h2>
    <p class="muted" style="max-width:62ch">Приложение тянет билет с упором на твои слабые темы, запускает таймер подготовки, а ИИ-экзаменатор ставит оценку и задаёт дополнительный вопрос. Генератор собирает комплекты экзаменационных билетов для группы.</p>
    <ul><li>Симулятор с таймером и оценкой по пятибалльной шкале</li><li>Генератор комплектов билетов</li><li>Синхронизация между телефоном и компьютером</li><li>Аудио-прогон карточек</li></ul>
    <button class="btn pro" data-act="goto-pro">Подключить Pro</button></section>`;
}
function genResult() {
  if (GEN.state === "loading") return `<section class="panel" style="margin-top:18px"><span class="spin"></span> ИИ составляет комплект билетов…</section>`;
  if (GEN.state === "error") return `<section class="panel" style="margin-top:18px"><span class="warn">${esc(GEN.err)}</span></section>`;
  return `<section style="margin-top:22px"><div class="row" style="margin-bottom:12px"><h2 class="grow" style="margin:0">Комплект: ${pl(GEN.list.length, "билет", "билета", "билетов")} ${GEN.ai ? `<span class="tag ai">ИИ</span>` : ""}</h2><button class="btn" data-act="gen-copy">Скопировать текстом</button></div>
    <div class="gen-list">${GEN.list.map((t, i) => `<article class="exam-ticket"><div class="hdr"><b>Билет №${i + 1}</b><span class="mono muted" style="font-size:12px">${esc(exDeck().name)}</span></div><ol>${t.map(q => `<li class="rich">${renderRich(q)}</li>`).join("")}</ol></article>`).join("")}</div></section>`;
}
function examHistory(d) {
  const ex = S.meta.exams.filter(e => e.deck === d.id).slice(-8).reverse();
  if (!ex.length) return "";
  return `<section class="panel" style="margin-top:22px"><h2>История экзаменов</h2><table class="t"><thead><tr><th>Дата</th><th>Билеты</th><th>Балл</th><th>Оценка</th></tr></thead><tbody>
    ${ex.map(e => `<tr><td>${new Date(e.t).toLocaleDateString("ru-RU", { day: "numeric", month: "short" })}</td><td class="mono">${e.nums.map(n => "№" + n).join(", ")}</td><td>${e.total}</td><td><b style="color:${e.mark >= 5 ? "var(--good)" : e.mark >= 4 ? "var(--cyan)" : e.mark >= 3 ? "var(--amber)" : "var(--bad)"}">${e.mark}</b></td></tr>`).join("")}</tbody></table></section>`;
}
function weightedPick(d, k) {
  const pool = d.tickets.map(t => ({ t, w: 1.25 - (ticketStat(d, t).m ?? 0.45) }));
  const out = [];
  while (out.length < k && pool.length) { const tot = sum(pool.map(p => p.w)); let r = Math.random() * tot, i = 0; for (; i < pool.length - 1; i++) { r -= pool[i].w; if (r <= 0) break; } out.push(pool[i].t); pool.splice(i, 1); }
  return out.sort((a, b) => a.num - b.num);
}
async function drawTicket() {
  const d = exDeck(); if (!d || !d.tickets.length) return;
  const tb = $("#exTask"); if (tb) EXSET.task = tb.checked;
  const picks = weightedPick(d, Math.min(EXSET.k, d.tickets.length));
  EX = { state: "drawing", deckId: d.id, no: S.meta.exams.length + 1, qs: picks.map(t => ({ kind: "theory", tid: t.id, num: t.num, text: t.title })), answers: [], res: null, minutes: EXSET.minutes };
  go("exam"); render();
  if (EXSET.task && !aiOn()) toast("Задачу от ИИ добавлю, когда подключишь нейросеть в профиле");
  if (EXSET.task && aiOn()) {
    const frags = []; picks.forEach(t => retrieve(d, t.title, 3).forEach(f => { if (!frags.some(x => x.id === f.id)) frags.push(f); }));
    const prompt = `Ты — преподаватель. Составь одно практическое задание (задачу) к экзаменационному билету.
Предмет: ${d.name}
Теоретические вопросы билета: ${picks.map(t => "«" + t.title + "»").join(", ")}
${frags.length ? "Материалы курса:\n" + fragBlock(frags) : "Материалы не загружены: задание должно проверять базовое понимание этих тем."}
Задание должно решаться за 5–7 минут, проверять понимание темы, а не память, и ${d.strict && frags.length ? "опираться только на материалы выше" : "соответствовать уровню курса"}. Формулы — LaTeX \\( ... \\).
Формат строго:
TASK: условие задачи
KEY: краткое эталонное решение и ответ`;
    try { const p = parseTagged(await ai(prompt, { cache: false }), ["TASK", "KEY"]); if (EX && p.TASK) EX.qs.push({ kind: "task", text: p.TASK, key: p.KEY || "" }); }
    catch (e) { toast("Задачу создать не удалось: " + aiErrText(e), "err"); }
  }
  if (!EX) return;
  EX.state = "answering"; EX.started = Date.now(); EX.answers = EX.qs.map(() => "");
  render();
}
function vExamRun() {
  const d = S.decks[EX.deckId]; if (!d) { EX = null; return vExam(); }
  if (EX.state === "drawing") return `<div class="rv-wrap"><section class="exam-ticket draw-anim"><div class="hdr"><b>Экзаменационный билет</b></div><p><span class="spin"></span> Тяну билет${EXSET.task && aiOn() ? " и составляю задачу" : ""}…</p></section></div>`;
  const qs = EX.qs.map((q, i) => {
    const r = EX.res && EX.res.items[i];
    const answerArea = EX.state === "answering" ? `<div class="answer-box" style="margin-top:10px"><textarea id="exA${i}" data-exa="${i}" placeholder="План ответа или полный ответ">${esc(EX.answers[i])}</textarea>${micBtn("#exA" + i)}</div><div class="partial"></div>`
      : `<div class="muted" style="margin-top:8px;white-space:pre-wrap;font-size:14px">${esc(EX.answers[i] || "(без ответа)")}</div>${r ? `<div class="aires" style="margin-top:10px;padding:12px 14px"><div class="row"><b class="mono" style="color:${r.s >= 75 ? "var(--good)" : r.s >= 50 ? "var(--amber)" : "var(--bad)"}">${r.s} / 100</b></div><div class="rich" style="margin-top:6px">${renderRich(r.f)}</div></div>` : ""}
        ${EX.state !== "answering" && !EX.res && !aiOn() ? refBlock(d, q) : ""}`;
    return `<div class="eq"><div class="n">${q.kind === "task" ? "З" : i + 1}</div><div><div class="rich" style="font-weight:600">${q.kind === "task" ? "<span class='tag ai' style='margin-right:6px'>задача</span>" : `<span class="mono muted" style="font-size:12px">билет №${q.num} · </span>`}${renderRich(q.text)}</div>${answerArea}</div></div>`;
  }).join("");
  let foot = "";
  if (EX.state === "answering") foot = `<div class="row" style="margin-top:16px">${aiOn() ? `<button class="btn ai solid" data-act="ex-submit">${ICON.spark} Сдать экзаменатору</button>` : `<button class="btn pri" data-act="ex-self">Показать эталоны</button>`}<button class="btn ghost" data-act="ex-cancel">Отменить</button></div>`;
  else if (EX.state === "grading") foot = `<div class="aires"><span class="spin"></span> Экзаменатор проверяет ответы…</div>`;
  else if (EX.state === "self") foot = `<div class="aires"><div class="lbl">Оцени себя честно</div><div class="row">${[2, 3, 4, 5].map(m => `<button class="btn" data-act="ex-selfmark" data-v="${m}">${m}</button>`).join("")}</div></div>`;
  else if (EX.res) {
    const r = EX.res, mk = r.final ?? r.mark;
    foot = `<div class="aires" style="display:grid;grid-template-columns:auto minmax(0,1fr);gap:22px;align-items:start">
      <div style="text-align:center"><div class="mark m${mk}">${mk}</div><div class="mono muted" style="font-size:12px;margin-top:4px">${r.total} / 100</div></div>
      <div class="stack"><div><div class="eyebrow m" style="margin:0 0 4px">экзаменатор</div><div class="rich">${renderRich(r.comment)}</div></div>
        ${r.extra ? (EX.state === "extra" ? `<div><div class="lbl">Дополнительный вопрос</div><div class="rich" style="font-weight:600;margin-bottom:8px">${renderRich(r.extra)}</div>
          <div class="answer-box"><textarea id="exX" placeholder="Ответ на дополнительный вопрос"></textarea>${micBtn("#exX")}</div><div class="partial"></div>
          <div class="row" style="margin-top:8px"><button class="btn ai solid" data-act="ex-extra">Ответить</button><button class="btn ghost" data-act="ex-finish">Без допвопроса</button></div></div>`
        : EX.state === "extra-grading" ? `<div><span class="spin"></span> Экзаменатор слушает ответ…</div>`
        : r.extraFb ? `<div><div class="lbl">Дополнительный вопрос</div><div class="rich" style="margin-bottom:6px">${renderRich(r.extra)}</div><div class="rich muted">${renderRich(r.extraFb)}</div></div>` : "") : ""}
        ${EX.state === "done" ? `<div class="row"><button class="btn pri" data-act="ex-draw">Тянуть следующий</button><button class="btn" data-act="ex-cancel">К настройкам</button></div>` : ""}</div></div>`;
  }
  const left = EX.started ? Math.max(0, EX.minutes * 60 - Math.floor((Date.now() - EX.started) / 1000)) : EX.minutes * 60;
  return `<div class="rv-wrap"><section class="exam-ticket draw-anim">
    <div class="hdr"><div><div class="eyebrow">${esc(d.name)}</div><b>Экзаменационный билет №${EX.no}</b></div>${EX.state === "answering" ? `<div class="timer ${left < 60 ? "low" : ""}" id="exTimer">${fmtT(left)}</div>` : ""}</div>
    ${qs}${foot}</section></div>`;
}
const fmtT = s => String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0");
function refBlock(d, q) {
  if (q.kind === "task") return q.key ? `<details style="margin-top:8px"><summary class="lbl" style="cursor:pointer">Эталон решения</summary><div class="rich">${renderRich(q.key)}</div></details>` : "";
  const cs = d.cards.filter(c => c.t === q.tid);
  return cs.length ? `<details style="margin-top:8px"><summary class="lbl" style="cursor:pointer">Эталон по карточкам</summary>${cs.map(c => `<div class="rich" style="margin:6px 0"><b>${renderRich(c.q)}</b>${renderRich(c.a)}</div>`).join("")}</details>` : "";
}
function afterExam() {
  clearInterval(_exTimer);
  $$("textarea[data-exa]").forEach(ta => ta.addEventListener("input", () => { if (EX) EX.answers[+ta.dataset.exa] = ta.value; }));
  if (EX && EX.state === "answering") _exTimer = setInterval(() => {
    const el = $("#exTimer"); if (!el || !EX || EX.state !== "answering") { clearInterval(_exTimer); return; }
    const left = Math.max(0, EX.minutes * 60 - Math.floor((Date.now() - EX.started) / 1000));
    el.textContent = left ? fmtT(left) : "время вышло"; el.classList.toggle("low", left < 60);
  }, 1000);
}
function examRef(d, q) {
  if (q.kind === "task") return "Эталонное решение: " + (q.key || "(нет)");
  const cs = d.cards.filter(c => c.t === q.tid).map(c => "• " + c.q + "\n" + c.a).join("\n").slice(0, 2500);
  const fr = retrieve(d, q.text, 3); return (cs ? "Карточки:\n" + cs + "\n" : "") + (fr.length ? "Фрагменты материалов:\n" + fragBlock(fr).slice(0, 3000) : "");
}
async function submitExam() {
  const d = S.decks[EX.deckId]; EX.state = "grading"; render();
  const prompt = `Ты — экзаменатор на устном экзамене в колледже. Оцени ответы студента по экзаменационному билету.
Предмет: ${d.name}
${EX.qs.map((q, i) => `===== Вопрос ${i + 1} (${q.kind === "task" ? "задача" : "теория"}): ${q.text}\nЭталон и материалы:\n${examRef(d, q)}\nОтвет студента:\n"""${(EX.answers[i] || "").slice(0, 4000) || "(нет ответа)"}"""`).join("\n\n")}

Критерии: полнота, точность терминов и формул, логика изложения. Пустой ответ — 0 баллов. Ответ мог быть надиктован голосом: опечатки не снижают балл. ${d.strict ? "Оценивай по материалам и эталону, не требуй того, чего в них нет." : ""}
Формулы — LaTeX \\( ... \\).
Формат строго:
${EX.qs.map((q, i) => `S${i + 1}: балл 0–100\nF${i + 1}: 1–3 предложения: что хорошо и чего не хватило`).join("\n")}
TOTAL: итоговый балл 0–100
MARK: оценка по пятибалльной шкале: 2, 3, 4 или 5
COMMENT: общий комментарий экзаменатора, 2–3 предложения, по-человечески
EXTRA: один дополнительный вопрос, который задал бы преподаватель, чтобы проверить слабое место`;
  try {
    const keys = ["TOTAL", "MARK", "COMMENT", "EXTRA"]; EX.qs.forEach((q, i) => keys.push("S" + (i + 1), "F" + (i + 1)));
    const p = parseTagged(await ai(prompt, { cache: false, tier: "default" }), keys);
    if (!EX) return;
    const items = EX.qs.map((q, i) => ({ s: clamp(parseInt(p["S" + (i + 1)], 10) || 0, 0, 100), f: p["F" + (i + 1)] || "" }));
    const total = clamp(parseInt(p.TOTAL, 10) || Math.round(sum(items.map(x => x.s)) / items.length), 0, 100);
    const mark = clamp(parseInt(p.MARK, 10) || (total >= 85 ? 5 : total >= 70 ? 4 : total >= 50 ? 3 : 2), 2, 5);
    EX.res = { items, total, mark, comment: p.COMMENT || "", extra: p.EXTRA || "" };
    saveExam(d, items, total, mark);
    EX.state = EX.res.extra ? "extra" : "done";
  } catch (e) { if (!EX) return; toast(aiErrText(e), "err"); EX.state = "answering"; }
  render();
}
function saveExam(d, items, total, mark) {
  EX.qs.forEach((q, i) => { if (q.kind === "theory") { const t = ticketOf(d, q.tid); if (t) t.exam = items ? items[i].s : Math.round((mark - 2) / 3 * 100); } });
  EX.rec = { t: Date.now(), deck: d.id, nums: EX.qs.filter(q => q.kind === "theory").map(q => q.num), total, mark };
  S.meta.exams.push(EX.rec); S.meta.exams = S.meta.exams.slice(-100);
  touch("deck-" + d.id); touch("meta");
}
async function extraAnswer() {
  const ans = ($("#exX")?.value || "").trim(); if (!ans) { toast("Ответь на вопрос или нажми «Без допвопроса»"); return; }
  const d = S.decks[EX.deckId], r = EX.res; EX.state = "extra-grading"; render();
  const prompt = `Ты — экзаменатор. Студент получил за билет ${r.total}/100 (оценка ${r.mark}). Ты задал дополнительный вопрос.
Предмет: ${d.name}
Дополнительный вопрос: ${r.extra}
Материалы:\n${EX.qs.filter(q => q.kind === "theory").map(q => examRef(d, q)).join("\n").slice(0, 5000)}
Ответ студента: """${ans.slice(0, 3000)}"""
Реши, меняется ли оценка: хороший ответ может поднять на балл, слабый — опустить или оставить.
Формат строго:
FINAL: итоговая оценка 2, 3, 4 или 5
FB: 1–2 предложения о дополнительном ответе`;
  try {
    const p = parseTagged(await ai(prompt, { cache: false }), ["FINAL", "FB"]);
    if (!EX) return;
    r.final = clamp(parseInt(p.FINAL, 10) || r.mark, 2, 5); r.extraFb = p.FB || "";
    if (EX.rec) { EX.rec.mark = r.final; touch("meta"); }
    EX.state = "done";
  } catch (e) { if (!EX) return; toast(aiErrText(e), "err"); EX.state = "extra"; }
  render();
}
async function genSet(useAi) {
  if (useAi && !aiOn()) { openAiSetup(); return; }
  const d = exDeck(); if (!d) return;
  GENSET.n = clamp(parseInt($("#genN")?.value, 10) || 10, 2, 40); GENSET.task = !!$("#genTask")?.checked;
  const ts = sortedTickets(d);
  if (!useAi) {
    const k = Math.min(GENSET.k, ts.length), list = []; let pool = [];
    for (let i = 0; i < GENSET.n; i++) {
      const tk = [];
      while (tk.length < k) { if (!pool.length) pool = ts.slice().sort(() => Math.random() - 0.5); const idx = pool.findIndex(t => !tk.includes(t)); tk.push(pool.splice(idx < 0 ? 0 : idx, 1)[0]); }
      list.push(tk.sort((a, b) => a.num - b.num).map(t => `${t.title} (№${t.num})`));
    }
    GEN = { deckId: d.id, state: "ok", list, ai: false }; render(); return;
  }
  GEN = { deckId: d.id, state: "loading" }; render();
  const frags = GENSET.task ? deckMaterials(d).flatMap(m => m.chunks.map((text, n) => ({ id: m.id + ":" + n, mat: m, n, text }))).slice(0, 14) : [];
  const prompt = `Ты — преподаватель, составляешь комплект экзаменационных билетов.
Предмет: ${d.name}
Вопросы программы (номер: формулировка):
${ts.map(t => t.num + ": " + t.title).join("\n")}

Составь ${GENSET.n} экзаменационных билетов. В каждом ${Math.min(GENSET.k, ts.length)} теоретических вопроса из списка: формулировку бери из списка без изменений, в конце укажи номер в скобках, например (№5). Вопросы в одном билете — из разных тем. Распредели вопросы равномерно: каждый вопрос программы должен встретиться хотя бы раз, если билетов хватает. Сложность билетов примерно одинаковая.
${GENSET.task ? `Добавь в каждый билет последним пунктом практическое задание, решаемое за 5–7 минут, начни его со слова «Задача:». ${frags.length ? "Опирайся на материалы:\n" + fragBlock(frags).slice(0, 9000) : ""}\nФормулы — LaTeX \\( ... \\).` : ""}
Формат строго, без вступления:
@@TICKET
1. ...
2. ...
@@END`;
  try {
    const text = await ai(prompt, { cache: false });
    const list = text.split("@@TICKET").slice(1).map(b => { const items = []; b.split("@@END")[0].split("\n").forEach(l => { const m = l.match(/^\s*\d+[.)]\s+(.*)$/); if (m) items.push(m[1]); else if (items.length && l.trim()) items[items.length - 1] += "\n" + l.trim(); }); return items; }).filter(x => x.length);
    if (!list.length) throw { code: "x", message: "ИИ вернул ответ в неожиданном формате, попробуй ещё раз" };
    GEN = { deckId: d.id, state: "ok", list, ai: true };
  } catch (e) { GEN = { deckId: d.id, state: "error", err: e && e.code === "x" ? e.message : aiErrText(e) }; }
  if (UI.view === "exam") render();
}

/* ============ экран: статистика ============ */
function vStats() {
  const decks = deckList(), days = S.meta.days || {};
  let streak = 0; for (let i = 0; i < 400; i++) { const k = dayKey(Date.now() - i * DAY); if (days[k]) streak++; else if (i > 0) break; }
  const today = days[dayKey()] || 0;
  const allCards = decks.flatMap(d => d.cards), learned = allCards.filter(c => (cardMastery(c) ?? 0) >= 0.75).length;
  const ex = S.meta.exams, avg = ex.length ? (sum(ex.map(e => e.mark)) / ex.length).toFixed(1) : "—";
  const weak = decks.flatMap(d => d.tickets.map(t => ({ d, t, s: ticketStat(d, t) }))).filter(x => x.s.m != null && x.s.m < 0.6).sort((a, b) => a.s.m - b.s.m).slice(0, 8);
  const N = 21, bars = []; for (let i = N - 1; i >= 0; i--) { const t = Date.now() - i * DAY; bars.push({ k: dayKey(t), v: days[dayKey(t)] || 0, d: new Date(t).getDate() }); }
  const mx = Math.max(5, ...bars.map(b => b.v)), W = 560, H = 160, bw = (W - 30) / N;
  const chart = `<svg viewBox="0 0 ${W} ${H + 22}" style="width:100%;height:auto" role="img" aria-label="Повторения за ${N} дней">
    ${[0, 0.5, 1].map(f => `<line x1="30" x2="${W}" y1="${H - f * H + 0.5}" y2="${H - f * H + 0.5}" stroke="rgba(139,145,180,.15)"/><text x="24" y="${H - f * H + 4}" fill="#5d6388" font-size="10" font-family="JetBrains Mono" text-anchor="end">${Math.round(f * mx)}</text>`).join("")}
    ${bars.map((b, i) => { const h = b.v / mx * H, last = i === N - 1; return `<rect x="${30 + i * bw + 2}" y="${H - h}" width="${bw - 4}" height="${Math.max(h, b.v ? 2 : 0)}" fill="${last ? "var(--pink)" : "var(--cyan)"}" opacity="${last ? 1 : 0.8}"><title>${b.k}: ${b.v}</title></rect>${i % 3 === 0 || last ? `<text x="${30 + i * bw + bw / 2}" y="${H + 15}" fill="${last ? "#ff9ccb" : "#5d6388"}" font-size="10" font-family="JetBrains Mono" text-anchor="middle">${b.d}</text>` : ""}`; }).join("")}
  </svg>`;
  return `<header class="vh"><div><div class="eyebrow">статистика</div><h1>Какие билеты проседают</h1></div></header>
  <div class="kpis">
    <div class="kpi"><span>серия</span><b>${pl(streak, "день", "дня", "дней")}</b></div>
    <div class="kpi"><span>ответов сегодня</span><b>${today}</b></div>
    <div class="kpi"><span>выучено карточек</span><b>${learned} <small class="muted" style="font-size:14px">/ ${allCards.length}</small></b></div>
    <div class="kpi"><span>экзаменов · ср. оценка</span><b>${ex.length} · ${avg}</b></div>
  </div>
  <div class="two">
    <div class="stack">${decks.map(d => { const ts = sortedTickets(d); return `<section class="panel"><div class="row" style="margin-bottom:12px"><h2 class="grow" style="margin:0">${esc(d.name)}</h2><span class="mono muted" style="font-size:12px">карта билетов</span></div>
      ${ts.length ? `<div class="heat">${ts.map(t => { const s = ticketStat(d, t); return `<button class="${lvClass(s.m)}" data-act="open-ticket" data-deck="${d.id}" data-tid="${t.id}" title="№${t.num} ${esc(t.title)} — ${lvLabel(s.m)}${s.m != null ? " " + Math.round(s.m * 100) + "%" : ""}">${t.num}</button>`; }).join("")}</div>` : `<div class="muted">Билетов нет</div>`}
      </section>`; }).join("")}
      <div class="legend"><span><i class="lv-weak"></i>слабый &lt;45%</span><span><i class="lv-mid"></i>в процессе</span><span><i class="lv-ok"></i>уверенно ≥75%</span><span><i class="lv-none"></i>не начат</span></div>
    </div>
    <div class="stack">
      <section class="panel"><div class="row" style="margin-bottom:10px"><h2 class="grow" style="margin:0">Слабые билеты</h2>${weak.length ? `<button class="btn sm pri" data-act="weak-all">Повторить</button>` : ""}</div>
        ${weak.length ? `<table class="t"><tbody>${weak.map(w => `<tr><td class="mono" style="color:var(--cyan)">№${w.t.num}</td><td>${esc(w.t.title)}<div class="mlab">${esc(w.d.name)}</div></td><td style="text-align:right;color:${lvColor(w.s.m)}" class="mono">${Math.round(w.s.m * 100)}%</td></tr>`).join("")}</tbody></table>` : `<div class="muted">Слабых билетов нет. Или ты ещё не начинал повторять.</div>`}</section>
      <section class="panel"><h2>Повторения за 3 недели</h2>${chart}</section>
    </div>
  </div>`;
}
</script>
