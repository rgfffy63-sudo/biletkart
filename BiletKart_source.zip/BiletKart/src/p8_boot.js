<script>
/* ============ запуск ============ */
(async function boot() {
  let loaded = null;
  try { const raw = localStorage.getItem("biletkart:v1"); if (raw) loaded = JSON.parse(raw); } catch (e) { }
  if (loaded && loaded.decks) { S = loaded; S.meta = Object.assign(defaultMeta(), S.meta || {}); S.meta.settings = Object.assign(defaultMeta().settings, S.meta.settings || {}); S.materials = S.materials || {}; _pristine = false; }
  else S = makeDemo();
  CAP.tts = makeTTS(); CAP.dict = makeDict(); if (CAP.dict) wireDictation(CAP.dict);
  updateSide();
  window.addEventListener("hashchange", route);
  await Promise.race([Promise.all([loadLib("marked"), loadLib("purify"), loadLib("hljs")]).catch(() => { }), new Promise(r => setTimeout(r, 4000))]);
  configLibs();
  route();
  loadLib("mathjax").catch(() => { });
  api("GET", "/api/config").then(c => { SERVER_OK.v = true; if (c.providers) for (const k in c.providers) PROVIDERS[k] = Object.assign(PROVIDERS[k] || {}, c.providers[k]); if (UI.view === "profile") render(); }).catch(() => { SERVER_OK.v = false; });
  if (ACC) { await refreshMe(); if (isPro()) syncPull(); if (UI.view === "profile") render(); }
  document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible" && isPro()) syncPull(); });
  if ("serviceWorker" in navigator && /^https?:$/.test(location.protocol) && !isNative()) navigator.serviceWorker.register("sw.js").catch(() => { });
})();
</script>
</body>
</html>
